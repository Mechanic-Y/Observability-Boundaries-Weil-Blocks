# Observability Boundaries V1.0 — FROZEN Package

**Status:** FROZEN  
**Freeze date:** 2026-09-21 (JST)

This package freezes the accepted Design v2 review artifacts for *Observability Boundaries for Near-Critical Weil Blocks*.

## 日本語

- JA/EN の数学本文、scope、code-to-paper bridge、および research agenda は freeze 前の監査で PASS 済みです。
- FROZEN PDF は、承認済み Design v2 Review PDF の**バイト列を一切再生成せず、そのまま copy/rename**したものです。
- PDF 内部に `Publication Candidate` / `Design v2 Review` 相当の表記が残る場合があります。これは byte integrity を優先して再組版しなかったためで、package status は本 README と `MANIFEST_SHA256.txt` により **V1.0 FROZEN** と定義します。
- 最終成果物の SHA-256 の唯一の正本は `MANIFEST_SHA256.txt` です。MANIFEST 自身は自己参照を避けるため hash 対象に含めません。
- `TYPESET_AUDIT_PRE_DESIGN_V2.md` は Design v2 前の typeset provenance です。最終 PDF byte identity には使用しません。

## English

- The JA/EN mathematical content, scope, code-to-paper bridge, and research agenda passed the pre-freeze audits.
- The FROZEN PDFs are **byte-for-byte copies** of the accepted Design v2 Review PDFs; they were not regenerated during freezing.
- Internal `Publication Candidate` / `Design v2 Review` wording may remain in the PDF. This is intentional: byte integrity was prioritized over re-typesetting. Package status is defined here and in `MANIFEST_SHA256.txt` as **V1.0 FROZEN**.
- `MANIFEST_SHA256.txt` is the sole authoritative list of final in-package SHA-256 hashes. It does not hash itself, avoiding self-reference.
- `TYPESET_AUDIT_PRE_DESIGN_V2.md` is retained as pre-Design-v2 provenance and is not authoritative for the final PDF byte hashes.

## Frozen PDF identity

- JA PDF pages: 31
- EN PDF pages: 32
- Accepted JA Design v2 SHA-256: `f4d79a8a8ee98878471d9a998f9c47abd8c8b6d00a4d94087de83543a75b10ad`
- Accepted EN Design v2 SHA-256: `9070f0b9e4bd05371c4ef425c092b5cf482e735c543f0e38e72057069740746a`
- Frozen copies verified byte-identical: **YES / YES**

## Research status

The proved content remains the fixed finite-dimensional single-pair classification. The following remain explicitly open research tracks:

1. Track A — non-vacuity of higher jet strata in the actual taper family.
2. Track B — aggregate spectral interaction.
3. Track C — changing-dimension / operator limits.
4. Track D — prior art and numerical detector robustness.

No open track is promoted to a theorem by this freeze.
