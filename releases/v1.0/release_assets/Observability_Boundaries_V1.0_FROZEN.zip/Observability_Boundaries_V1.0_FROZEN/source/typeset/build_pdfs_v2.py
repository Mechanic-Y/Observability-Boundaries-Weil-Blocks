from pathlib import Path
import re, subprocess, textwrap, shutil, os

ROOT = Path('/mnt/data/pdf_design_v2')
SRC = Path('/mnt/data')

FIGS = {
    'ja': {
        1: ('fig1.pdf', 0.86, '臨界線近傍のreflection-pair collision geometry。$\\rho\\leftrightarrow1-\\bar\\rho$ はordinateを保存する上半平面のreflection pairであり、global quartetを一つのblockへ縮約する図ではない。'),
        2: ('fig2.pdf', 0.98, '現行formalizationからsingle-pair blockへ至るzero-side bridge。Weil-form layerのconjugationはSchwarz symmetryによりtranspose型zero-side productへ還元され、\\texttt{Gz\\_eq\\_W} が両レイヤーを接続する。'),
        3: ('fig3.pdf', 0.90, 'Exact negative detection with vanishing geometric margin（generic $q=0$ branch）。$\\delta\\neq0$ ではnegative-presence detectorはexactに反応する一方、$\\mu_-(W_\\delta)=|\\lambda_-(\\delta)|\\to0$。higher-order branchは別分類である。'),
        4: ('fig4.pdf', 0.96, 'Information-flow classificationとscope boundary。青枠は本稿で証明したfixed finite-dimensional single-pair layer、破線のamber枠はaggregate側およびTrack A--Dのopen researchを示す。'),
    },
    'en': {
        1: ('fig1.pdf', 0.86, 'Critical-line collision geometry for the reflection pair. The orbit $\\rho\\leftrightarrow1-\\bar\\rho$ preserves the ordinate and is not obtained by collapsing the full conjugation quartet into one block.'),
        2: ('fig2.pdf', 0.98, 'Zero-side bridge from the current formalization to the single-pair block. Schwarz symmetry converts the conjugated Weil-form summand into the transpose-type zero-side product, and \\texttt{Gz\\_eq\\_W} connects the two layers.'),
        3: ('fig3.pdf', 0.90, 'Exact negative detection with vanishing geometric margin in the generic $q=0$ branch. For $\\delta\\neq0$ the negative-presence detector responds exactly, while $\\mu_-(W_\\delta)=|\\lambda_-(\\delta)|\\to0$. Higher-order branches are classified separately.'),
        4: ('fig4.pdf', 0.96, 'Information-flow classification and scope boundary. Blue boxes mark the proved fixed finite-dimensional single-pair layer; dashed amber boxes mark aggregate questions and Tracks A--D as open research.'),
    }
}

HEADER_BASE = r'''
\usepackage{fontspec}
\usepackage{xeCJK}
\setmainfont{Noto Serif}
\setsansfont{Noto Sans}
\setmonofont{Noto Sans Mono}
\setCJKmainfont{Noto Serif CJK JP}
\setCJKsansfont{Noto Sans CJK JP}
\setCJKmonofont{Noto Sans Mono CJK JP}
\usepackage[a4paper,top=25mm,bottom=25mm,left=25mm,right=25mm,headheight=15pt]{geometry}
\usepackage{amsmath,amssymb,mathtools}
\usepackage{graphicx}
\graphicspath{{../figures/}}
\usepackage{booktabs,longtable,array,multirow,calc}
\usepackage{etoolbox}
\usepackage{colortbl}
\definecolor{OBblue}{HTML}{24527A}
\definecolor{OBred}{HTML}{A33A3A}
\definecolor{OBamber}{HTML}{A66A12}
\definecolor{OBgray}{HTML}{515967}
\AtBeginEnvironment{longtable}{\small\rowcolors{2}{OBblue!4}{white}}
\setlength{\LTpre}{7pt}
\setlength{\LTpost}{7pt}
\renewcommand{\arraystretch}{1.16}
\usepackage{microtype}
\usepackage{enumitem}
\setlist{itemsep=2pt,topsep=5pt,leftmargin=2em}
\usepackage{caption}
\captionsetup{font=small,labelfont=bf,textfont=it,justification=centering,skip=7pt}
\usepackage{float}
\usepackage{titlesec}
\titleformat{\section}{\Large\bfseries\color{OBblue}}{}{0pt}{}
\titleformat{\subsection}{\large\bfseries\color{OBblue!85!black}}{}{0pt}{}
\titleformat{\subsubsection}{\normalsize\bfseries\color{OBgray}}{}{0pt}{}
\titlespacing*{\section}{0pt}{2.2ex plus .4ex}{1.0ex}
\titlespacing*{\subsection}{0pt}{1.8ex plus .3ex}{.8ex}
\titlespacing*{\subsubsection}{0pt}{1.4ex plus .2ex}{.6ex}
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\fancyfoot[C]{\small\color{OBgray}\thepage}
\renewcommand{\headrulewidth}{0.35pt}
\renewcommand{\footrulewidth}{0pt}
\usepackage{xurl}
\urlstyle{same}
\setcounter{secnumdepth}{0}
\setcounter{tocdepth}{2}
\setlength{\parindent}{1em}
\setlength{\parskip}{0.25em}
\setlength{\emergencystretch}{3em}
\widowpenalty=10000
\clubpenalty=10000
\displaywidowpenalty=10000
\interdisplaylinepenalty=2500
\allowdisplaybreaks[2]
\providecommand{\tightlist}{\setlength{\itemsep}{0pt}\setlength{\parskip}{0pt}}
'''

def header(lang):
    if lang == 'ja':
        extra = r'''
\renewcommand{\contentsname}{目次}
\fancyhead[L]{\small\color{OBgray}Observability Boundaries — Japanese}
\fancyhead[R]{\small\color{OBgray}Version 1.0}
'''
    else:
        extra = r'''
\fancyhead[L]{\small\color{OBgray}Observability Boundaries — English}
\fancyhead[R]{\small\color{OBgray}Version 1.0}
'''
    return HEADER_BASE + extra


def title_block(lang):
    if lang == 'ja':
        return r'''
\hypersetup{pageanchor=false}
\begin{titlepage}
  \thispagestyle{empty}
  \centering
  \vspace*{14mm}
  {\color{OBblue}\rule{\textwidth}{1.2pt}}\\[14mm]
  {\fontsize{22}{27}\selectfont\bfseries\color{OBblue}
  臨界線近傍の Weil ブロックにおける可観測性境界\par}
  \vspace{5mm}
  {\fontsize{15}{20}\selectfont\color{OBgray}
  臨界線外零点衝突の有限次元解析\par}
  \vspace{11mm}
  {\large\bfseries Observability Boundaries for Near-Critical Weil Blocks\par}
  \vspace{2mm}
  {\normalsize A Finite-Dimensional Analysis of Off-Line Zero Collisions\par}
  \vfill
  {\large\bfseries Version 1.0 — Publication Candidate Working Draft\par}
  \vspace{14mm}
  {\large 脇田 泰行 (Yasuyuki Wakita / Mechanic-Y)\par}
  \vspace{2mm}
  {\normalsize 独立研究者 (Independent Researcher)\par}
  \vspace{12mm}
  {\normalsize 2026年9月\par}
  \vspace{14mm}
  {\color{OBblue}\rule{\textwidth}{1.2pt}}
\end{titlepage}
\hypersetup{pageanchor=true}
\pagenumbering{roman}
\begingroup
\small
\tableofcontents
\endgroup
\clearpage
\pagenumbering{arabic}
'''
    return r'''
\hypersetup{pageanchor=false}
\begin{titlepage}
  \thispagestyle{empty}
  \centering
  \vspace*{14mm}
  {\color{OBblue}\rule{\textwidth}{1.2pt}}\\[14mm]
  {\fontsize{22}{27}\selectfont\bfseries\color{OBblue}
  Observability Boundaries for Near-Critical Weil Blocks\par}
  \vspace{5mm}
  {\fontsize{15}{20}\selectfont\color{OBgray}
  A Finite-Dimensional Analysis of Off-Line Zero Collisions\par}
  \vfill
  {\large\bfseries Version 1.0 — Publication Candidate Working Draft\par}
  \vspace{14mm}
  {\large Yasuyuki Wakita (Mechanic-Y)\par}
  \vspace{2mm}
  {\normalsize Independent Researcher\par}
  \vspace{12mm}
  {\normalsize September 2026\par}
  \vspace{14mm}
  {\color{OBblue}\rule{\textwidth}{1.2pt}}
\end{titlepage}
\hypersetup{pageanchor=true}
\pagenumbering{roman}
\begingroup
\small
\tableofcontents
\endgroup
\clearpage
\pagenumbering{arabic}
'''


def strip_title(md: str, lang: str) -> str:
    parts = md.split('\n---\n', 1)
    if len(parts) != 2:
        raise RuntimeError('initial horizontal rule not found')
    body = parts[1].lstrip('\n')
    if lang == 'ja':
        body = body.replace('## 要旨', r'''\section*{要旨}
\addcontentsline{toc}{section}{要旨}''', 1)
    else:
        body = body.replace('## Abstract', r'''\section*{Abstract}
\addcontentsline{toc}{section}{Abstract}''', 1)
    return body


def insert_figures(md: str, lang: str) -> str:
    for num in range(1, 5):
        if lang == 'ja':
            start_re = rf'^> \*\*図{num} 挿入位置[^\n]*\n'
        else:
            start_re = rf'^> \*\*Figure {num} insertion point[^\n]*\n'
        m = re.search(start_re, md, flags=re.M)
        if not m:
            raise RuntimeError(f'figure marker {lang} {num} not found')
        end = m.end()
        lines = md[end:].splitlines(keepends=True)
        consumed = 0
        for line in lines:
            if line.startswith('>'):
                consumed += len(line)
            else:
                break
        block_end = end + consumed
        filename, width, caption = FIGS[lang][num]
        latex = textwrap.dedent(rf'''

\begin{{figure}}[htbp]
\centering
\includegraphics[width={width:.2f}\linewidth,keepaspectratio]{{{filename}}}
\caption{{{caption}}}
\label{{fig:{num}}}
\end{{figure}}

''')
        md = md[:m.start()] + latex + md[block_end:]
    return md


def build(lang: str, source_name: str):
    outdir = ROOT / lang
    outdir.mkdir(parents=True, exist_ok=True)
    md = (SRC / source_name).read_text(encoding='utf-8')
    md = strip_title(md, lang)
    md = insert_figures(md, lang)
    md = md.replace('JA↔EN', r'JA\(\leftrightarrow\)EN')
    long_box = r'''\boxed{
\text{state distinction}\ ;\ 
\text{discontinuous exact detection}\ ;\ 
\text{vanishing geometric margin / continuous no-gap}
}'''
    compact_box = r'''\boxed{
\begin{gathered}
\text{state distinction}\\
\text{discontinuous exact detection}\\
\text{vanishing geometric margin / continuous no-gap}
\end{gathered}
}'''
    md = md.replace(long_box, compact_box)
    body_md = outdir / 'body.md'
    body_md.write_text(md, encoding='utf-8')
    h = outdir / 'header.tex'; h.write_text(header(lang), encoding='utf-8')
    t = outdir / 'title.tex'; t.write_text(title_block(lang), encoding='utf-8')
    tex = outdir / f'Observability_Boundaries_V1.0_{lang.upper()}_Design_v2.tex'
    cmd = [
        'pandoc', str(body_md),
        '--from=markdown+raw_tex+tex_math_dollars+tex_math_single_backslash+tex_math_double_backslash',
        '--to=latex','--standalone','--pdf-engine=xelatex','-V','fontsize=11pt',
        f'--include-in-header={h}', f'--include-before-body={t}',
        '--wrap=preserve','--columns=120','-o',str(tex)
    ]
    subprocess.run(cmd, check=True, cwd=outdir)
    s = tex.read_text(encoding='utf-8')
    s = s.replace(r'\texttt{Zeta23/Hypotheses/GzGp.lean}', r'\path{Zeta23/Hypotheses/GzGp.lean}')
    s = re.sub(
        r'''\\boxed\{\s*\\text\{state distinction\}\\ ;\\\s*\\text\{discontinuous exact detection\}\\ ;\\\s*\\text\{vanishing geometric margin / continuous no-gap\}\s*\}''',
        r'''\\boxed{\\begin{gathered}\\text{state distinction}\\\\\\text{discontinuous exact detection}\\\\\\text{vanishing geometric margin / continuous no-gap}\\end{gathered}}''',
        s, flags=re.S)
    # Keep the detector-class distinction box readable at 11pt.
    s = s.replace(
        r'\boxed{\text{state distinction}\ ;\ \text{specified detectorによるexact detection}\ ;\ \text{robust/depth-uniform separation}}',
        r'\boxed{\begin{gathered}\text{state distinction}\\\text{specified detectorによる exact detection}\\\text{robust / depth-uniform separation}\end{gathered}}')
    s = s.replace(
        r'\boxed{\text{state distinction}\ ;\ \text{exact detection by a specified detector}\ ;\ \text{robust/depth-uniform separation}}',
        r'\boxed{\begin{gathered}\text{state distinction}\\\text{exact detection by a specified detector}\\\text{robust / depth-uniform separation}\end{gathered}}')
    if lang == 'ja':
        meta = r'''\hypersetup{colorlinks=true,linkcolor=OBblue,citecolor=OBblue,urlcolor=OBblue,pdftitle={臨界線近傍の Weil ブロックにおける可観測性境界},pdfauthor={Yasuyuki Wakita},pdfsubject={Observability Boundaries for Near-Critical Weil Blocks}}'''
    else:
        meta = r'''\hypersetup{colorlinks=true,linkcolor=OBblue,citecolor=OBblue,urlcolor=OBblue,pdftitle={Observability Boundaries for Near-Critical Weil Blocks},pdfauthor={Yasuyuki Wakita},pdfsubject={A Finite-Dimensional Analysis of Off-Line Zero Collisions}}'''
    s = s.replace('\\begin{document}', meta + '\n\\begin{document}', 1)
    tex.write_text(s, encoding='utf-8')
    with (outdir/'latexmk.stdout').open('w') as fh:
        subprocess.run(['latexmk','-xelatex','-interaction=nonstopmode','-halt-on-error',tex.name], check=True, cwd=outdir, stdout=fh, stderr=subprocess.STDOUT)
    return tex, tex.with_suffix('.pdf')

if __name__ == '__main__':
    print(build('ja','Observability_Boundaries_V1.0_JA_Publication_Candidate.md'))
    print(build('en','Observability_Boundaries_V1.0_EN_Publication_Candidate.md'))
