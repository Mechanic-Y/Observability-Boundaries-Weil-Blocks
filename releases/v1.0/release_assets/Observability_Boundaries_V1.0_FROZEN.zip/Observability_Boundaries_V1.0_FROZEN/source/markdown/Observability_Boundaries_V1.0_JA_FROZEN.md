# 臨界線近傍の Weil ブロックにおける可観測性境界

## — 臨界線外零点衝突の有限次元解析 —

**Observability Boundaries for Near-Critical Weil Blocks**  
**— A Finite-Dimensional Analysis of Off-Line Zero Collisions —**

**Version 1.0 — Publication Candidate Working Draft**

**脇田 泰行（Yasuyuki Wakita / Mechanic-Y）**  
**独立研究者（Independent Researcher）**

**2026年9月**

---

## 要旨

本稿は、Weil型zero-side finite-dimensional matrixに現れるsingle off-line reflection pairがcritical lineへ衝突する局所極限を解析する。現行Alpöge–Furman / Anthropic formalizationのzero-side pair contribution

\[
m\left(u u^T+\bar u\,\bar u^T\right)=2m\left(xx^T-yy^T\right)
\]

をlocal parameter \(u_\delta=h(t-i\delta)\) で表し、\(\delta\to0\) におけるmatrix collision、negative direction、およびdetector regularityの関係を調べる。

まず、

\[
W_\delta-W_0=O(\delta^2)
\]

を得る。従って \(W_0\) で連続な任意のfinite-dimensional matrix observable \(F\) について \(F(W_\delta)\to F(W_0)\) であり、collision近傍にdepth-independentなpositive output separationは存在しない。これは \(\delta\to0\) のcollision-limit statementであり、off-line depthが0から正に離れて固定される集合上でpositive separationが存在する可能性を排除しない。locally Lipschitzな \(F\) についてはoutput differenceも \(O(\delta^2)\) である.

一方、generic nondegeneracy condition

\[
x_0\neq0,\qquad P_\perp h'(t)\neq0
\]

の下では、十分小さい非零 \(\delta\) に対してnegative directionはexactに存在し、

\[
\lambda_-(\delta)=-2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4).
\]

従ってnegative-presence detectorはcollision pointをexactに区別するが、その判定を支えるgeometric robustness marginは \(O(\delta^2)\) で0へ縮退する。

さらに \(x_0\neq0\) のhigher-order degenerate branchについて、transverse component \(r(\delta)=P_{x_\delta^\perp}y_\delta\) の最初の非零項が

\[
r(\delta)=\delta^{2q+1}w+O(\delta^{2q+3})
\]

ならば、

\[
\lambda_-(\delta)=-2m\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4})
\]

となる。従って可能なleading ordersは \(2,6,10,14,\ldots\) であり、この系列はreal-symmetric analytic model class内でsharpである。

本稿の結果は固定有限次元・固定collision ordinateにおけるsingle-pair local analysisに限定される。RHの証明、Alpöge–Furman法全体へのno-go、interacting multi-pair system、またはinfinite-dimensional limitについての結論を主張しない。

# 1. 背景・目的・主張範囲

## 1.1 背景

Weilの明示公式に付随する二次形式は、零点側の情報と素数側の情報を結び付ける。有限次元化されたzero-side matrixでは、臨界線上の零点と、関数等式によって対をなす臨界線外零点とが、異なる符号構造を持つblockとして現れ得る。

Alpöge–Furmanによる2026年の論文 *More than two thirds of the zeta zeros are simple and on the critical line* は、有限次元zero-side matrixのrankおよびpositive indexと、prime sideから評価されるtrace量を組み合わせる。その議論はoff-line pairのdepthそのものを一様に下から評価するのではなく、有限次元二次形式の符号数とrankをexactに利用する。

本稿は、このzero-side構造から一つの対称pair blockを取り出し、

\[
\rho_\pm=\frac12\pm\delta+i\gamma
\]

が $\delta\to0$ で臨界線上へ衝突する際に、行列、固有値、および連続observableがどのように縮退するかを局所的に記述する。

## 1.2 目的

本稿の目的は、新しいglobal Weil theoryを提案することではない。現行zero-side constructionからsingle reflection-pair contributionを明示的に抽出し、そのcollision limitにおいて次の事項を区別・分類することにある。

1. matrix stateそのもののlocal collision rate。
2. continuous detector classにおけるoutput separationの消失。
3. discontinuous negative-presence detectorによるexact detection。
4. exact detectionを支えるgeometric robustness marginの消失。
5. generic quadratic branchが消える場合のhigher-order transverse degeneration。
6. 適用範囲・失敗経路・未解決領域を明示し、過大なglobal claimへ拡張しないこと。

個々の解析手法は有限次元Taylor展開、rank-two matrix algebra、および連続性に基づく。本稿が主張する内容は、この特定のzero-side pair structureにおける局所的な組合せと分類に限定する。

## 1.3 本稿が主張しないこと

本稿は次を主張しない。

- RHの証明、RHへの接近、またはRHの真偽に関する新しい含意。
- Alpöge–Furman / Anthropic formalization全体に対するabsolute no-go。
- PairCeiling、または約0.682という数値が、全手法に適用されるという主張。
- higher traces、非線形observable、非連続observable、無限次元極限、または算術的入力を含む全構成への一般化。
- historical priority、世界初、史上初、または先行研究の不存在。

本稿の文献調査上の表現は、「調査範囲では同一の局所漸近式を確認できなかったが、先行研究の完全な不存在を主張するものではない」に限定する。

---

# 2. 有限次元zero-side blockの設定

## 2.1 零点対とcomplex ordinate

臨界線に関して対称な上半平面の零点対を

\[
\rho_+(\delta)=\frac12+\delta+i\gamma,
\qquad
\rho_-(\delta)=\frac12-\delta+i\gamma
=1-\overline{\rho_+(\delta)}
\tag{2.1}
\]

とする。ここで $\gamma\in\mathbb R$、$\delta\in\mathbb R$ であり、局所解析では

\[
t:=\gamma
\]

と置く。

零点 $\rho=\beta+i\gamma$ に対するcomplex ordinateを

\[
z_\rho
:=\frac{\rho-\frac12}{i}
=\gamma-i\left(\beta-\frac12\right)
\tag{2.2}
\]

と定義する。したがって

\[
z_{\rho_+(\delta)}=t-i\delta,
\qquad
z_{\rho_-(\delta)}=t+i\delta.
\tag{2.3}
\]

> **図1 挿入位置：critical-line collision geometry**  
> 複素 $s$-平面に $\rho_\pm=\frac12\pm\delta+i\gamma$ と臨界線 $\Re s=\frac12$ を描き、$\delta\to0$ で同じ点 $\frac12+i\gamma$ へ衝突することを示す。ここで描くのは上半平面の関数等式対であり、全四重点を必要としない。

本稿でいうreflection pairは、involution \(\sigma(\rho):=1-\bar\rho\) によるorbit
\[
\{\rho,\sigma(\rho)\}=\{\beta+i\gamma,\;1-\beta+i\gamma\}
\]
を意味する。このinvolutionはordinate \(\gamma\) を保存し、現行zero-side block decompositionで用いられているoff-line pairingそのものである。

これはglobal zero setのconjugation symmetryから得られるquartet
\[
\{\beta\pm i\gamma,\;1-\beta\pm i\gamma\}
\]
全体を一つのblockへ縮約する操作ではない。下半平面のconjugate zerosは別のsymmetry orbitに属し、本稿のsingle-pair identity `pair_term` の導出には必要ない。

## 2.2 Evaluation family

$U\subset\mathbb C$ を $t\in\mathbb R$ の開近傍とし、必要なら $t$ の周囲で共役に関して対称な近傍へ縮小する。有限次元evaluation familyを

\[
h:U\longrightarrow\mathbb C^d
\tag{2.4}
\]

とし、$h$ はholomorphicであると仮定する。real-symmetric caseとして

\[
h(\overline z)=\overline{h(z)}
\tag{2.5}
\]

を仮定する。特に $h(t)\in\mathbb R^d$ であり、すべての導関数 $h^{(k)}(t)$ は実ベクトルである。

十分小さい実数 $\delta$ に対し

\[
u_\delta
:=h(t-i\delta)
=x_\delta+i y_\delta,
\qquad
x_\delta,y_\delta\in\mathbb R^d
\tag{2.6}
\]

と書く。式 (2.5) から

\[
h(t+i\delta)=\overline{u_\delta},
\qquad
x_{-\delta}=x_\delta,
\qquad
y_{-\delta}=-y_\delta
\tag{2.7}
\]

が従う。

## 2.3 現行zero-side構造からのsingle-pair blockの導出

本稿で用いるsingle-pair blockは、任意に導入したrank-two toy modelではない。本節では、Alpöge–Furman 2026に対応する現行Anthropic Lean実装のzero-side matrixから、式 (2.8) を抽出する。

V1.0では、参照実装を

\[
\texttt{anthropics/formal-math}
\]

の `zeta23/` projectとし、監査snapshotを

\[
\boxed{\texttt{fbdc36bbf17d20af3fd0447c6d1a8a02773c9844}}
\]

に固定する。旧standalone repository `anthropics/zeta-23-lean` も研究履歴上存在するが、本稿V1.0のsource bindingは上記snapshotに統一する。

### 2.3.1 Complex ordinate and reflection

`Zeta23/Defs.lean` では \(\gamma_\rho=(\rho-\frac12)/i\) が `gammaOf` として定義される。\(\rho=\beta+i\gamma\) ならば

\[
\gamma_\rho=\gamma-i\left(\beta-\frac12\right).
\tag{2.8a}
\]

reflectionは \(\sigma(\rho)=1-\bar\rho\) として実装され、\(\gamma_{\sigma(\rho)}=\overline{\gamma_\rho}\) である。

### 2.3.2 Zero-side evaluation vector and transpose matrix

現行 `ZeroSide.lean` のfinite-dimensional zero-side constructionでは、

\[
u_\rho=\left(\widehat\phi(\gamma_\rho-\tau_k)\right)_{k<d}\in\mathbb C^d
\tag{2.8b}
\]

をevaluation vectorとして用いる。同ファイルの `blockA` は

\[
\boxed{A=\sum_\rho m_\rho u_\rho u_\rho^T}
\tag{2.8c}
\]

として定義される。ここで \(T\) はtransposeであり、conjugate transposeではない。entrywiseには `blockA_apply` により

\[
A_{kl}=\sum_\rho m_\rho\widehat\phi(\gamma_\rho-\tau_k)\widehat\phi(\gamma_\rho-\tau_l).
\tag{2.8d}
\]

### 2.3.3 Reflection-pair contribution

zero configurationはreflectionについて不変であり、\(m_{\sigma(\rho)}=m_\rho\)、\(u_{\sigma(\rho)}=\overline{u_\rho}\) を満たす。従ってoff-line reflection pairの `blockA` への寄与は

\[
W_\rho=m_\rho\left(u_\rho u_\rho^T+\overline{u_\rho}\,\overline{u_\rho}^{\,T}\right).
\tag{2.8e}
\]

\(u_\rho=x_\rho+i y_\rho\) と書けば、

\[
\boxed{W_\rho=2m_\rho\left(x_\rho x_\rho^T-y_\rho y_\rho^T\right)}.
\tag{2.8f}
\]

このidentityは `Zeta23/ZeroSide.lean` の lemma `pair_term` として形式証明されている。また `blockA_decomp` により off-line pairの正・負rank-one成分が分離される。

### 2.3.4 Weil formとのレイヤー区別とtranspose型entryへの還元

zero-side matrix `blockA` とWeil sesquilinear form `W(f,g)` を混同しない。`blockA` のentryは
\[
m_\rho\widehat\phi(\gamma_\rho-\tau_k)\widehat\phi(\gamma_\rho-\tau_l)
\tag{2.8g}
\]
というtranspose型productである。一方、`Defs.lean` の `Wsummand` は
\[
m_\rho h_{f_k}(\gamma_\rho)\overline{h_{f_l}(\overline{\gamma_\rho})}
\tag{2.8h}
\]
というconjugationを含む。

選択されたtest familyについて `paperFT_fk` は
\[
h_{f_k}(z)=\widehat\phi(z-\tau_k)
\tag{2.8i}
\]
を与える。また \(\phi\) がreal-valued and evenであることから、`Zeta23/Hypotheses/GzGp.lean` の `GzGp.phiHat_conj` はSchwarz symmetry
\[
\widehat\phi(\bar z)=\overline{\widehat\phi(z)}
\tag{2.8j}
\]
を与える。実軸実値性はこのsymmetryの帰結である。

\(\tau_l\in\mathbb R\) なので
\[
\overline{\gamma_\rho}-\tau_l=\overline{\gamma_\rho-\tau_l},
\]
従って
\[
\begin{aligned}
\overline{h_{f_l}(\overline{\gamma_\rho})}
&=\overline{\widehat\phi(\overline{\gamma_\rho}-\tau_l)}\\
&=\overline{\widehat\phi(\overline{\gamma_\rho-\tau_l})}\\
&=\widehat\phi(\gamma_\rho-\tau_l).
\end{aligned}
\tag{2.8k}
\]
したがってWeil zero-side summandはtermwiseに
\[
\boxed{m_\rho\widehat\phi(\gamma_\rho-\tau_k)\widehat\phi(\gamma_\rho-\tau_l)}
\tag{2.8l}
\]
へ還元され、`blockA` のtranspose型entryと一致する。

ここで用いているのはsame-argument Hermitian product \(u_\rho u_\rho^*\) ではない。conjugationは \(h_{f_l}(\overline{\gamma_\rho})\) に作用した後、Schwarz symmetryによってtranspose-type evaluationへ戻される。従って
\[
u u^T+\bar u\,\bar u^T=2(xx^T-yy^T)
\]
というindefinite pair structureは単なるmatrix conventionではなく、このtest familyに対するWeil zero-side summandの実際の形である。

このtermwise identityはsnapshot `fbdc36bb...` の `Zeta23/Hypotheses/GzGp.lean` において、`paperFT_fk`, `GzGp.phiHat_conj`, `Gz_eq_W` の `rw` 連鎖として形式証明されている。

### 2.3.5 Local collision family

以上より、本稿で解析する

\[
u_\delta:=h(t-i\delta)=x_\delta+i y_\delta
\]

および

\[
\boxed{W_\delta=m\left(u_\delta u_\delta^T+\overline{u_\delta}\,\overline{u_\delta}^{\,T}\right)=2m\left(x_\delta x_\delta^T-y_\delta y_\delta^T\right)}
\tag{2.8}
\]

は、現行zero-side matrix `blockA` に現れるsingle off-line reflection pair contribution `pair_term` を局所parameter化したものである。

> **図2 挿入位置：zero-side bridge**  
> `gammaOf` → evaluation vector \(u_\rho\) → `blockA` contribution → reflection pair → `pair_term` \(2m(xx^T-yy^T)\) の流れを示す。`Wsummand` と `blockA` は別レイヤーであり、`Gz_eq_W` がbridgeすることを明示する。

### 注意2.3.1（scope）

このbridgeが立証するのは
\[
\boxed{\text{single reflection-pair contribution}\longleftrightarrow W_\delta}
\]
の対応のみである。§§3–8のどの定理も、pair decompositionだけを根拠としてfull aggregate `blockA` のspectrumへ適用されるとは主張しない。

aggregate matrixは代数的には
\[
A=A_{\rm on}+\sum_jW_j
\]
と書けるが、一般に
\[
\operatorname{spec}\!\left(\sum_jW_j\right)
\]
は各 \(W_j\) のspectraのunionではない。従って問題は定義上の追加「cross-term」ではなく、同一ambient space上で重なるpair blocks間のspectral interactionである。

本稿は、このinteractionに対するseparation、orthogonality、commutativity、またはperturbative decoupling conditionを導出しない。exact direct-sum caseを除くaggregate spectral analysisは本稿の適用範囲外である。

## 2.4 ノルム、state distinction、detector、およびrobustness margin

ベクトルノルムにはEuclidean norm \(\lVert\cdot\rVert\)、行列ノルムにはoperator norm \(\lVert\cdot\rVert_{\mathrm{op}}\) を用いる。固定有限次元では標準的な行列ノルムは同値である。

実対称行列 \(A\) の負固有値数を重複度込みで \(n_-(A)\) と書く。

### 2.4.1 Exact state distinction

ある \(\delta_0>0\) が存在して

\[
0<|\delta|<\delta_0\Longrightarrow W_\delta\neq W_0
\tag{2.11}
\]

が成り立つとき、state自体がexactに異なるという。これはrobust detectionを意味しない。

### 2.4.2 Detector distinction

写像 \(D:\operatorname{Sym}_d(\mathbb R)\to Y\) をdetectorとする。negative directionの存在を判定するdetectorとして

\[
\chi_-(A):=\mathbf 1_{\{\lambda_{\min}(A)<0\}}
\tag{2.12}
\]

を定義する。\(\chi_-\) はPSD境界上で不連続である。full inertia count \(n_-\) はexactな代数情報として用いるが、ambient perturbation robustnessの尺度とはみなさない。

### 2.4.3 Geometric robustness margin

\[
\mu_-(A):=\operatorname{dist}_{\mathrm{op}}(A,\operatorname{PSD}_d)=\max\{0,-\lambda_{\min}(A)\}.
\tag{2.13}
\]

\(\mu_-\) はnegative-presence判定を失うまでの最小operator-norm perturbationであり、距離関数として1-Lipschitzである。

### 2.4.4 Continuous matrix observables

有限次元ノルム空間 \(Y\) への写像 \(F:\operatorname{Sym}_d(\mathbb R)\to Y\) をcontinuous matrix observableとして扱い、

\[
\Delta_F(\delta):=\lVert F(W_\delta)-F(W_0)\rVert_Y
\tag{2.14}
\]

とする。ある \(c>0\) があり十分小さい全ての非零depthで \(\Delta_F(\delta)\ge c\) なら、depth-uniform positive output separationを持つという。

本稿では

\[
\boxed{\text{state distinction}\ ;\ \text{specified detectorによるexact detection}\ ;\ \text{robust/depth-uniform separation}}
\tag{2.15}
\]

を明示的に区別する。

# 3. OB-1：Explicit Quadratic Collision Coefficient

real symmetryとanalyticityから \(W_{-\delta}=W_\delta\) なので、\(W_\delta-W_0=O(\delta^2)\) という二次開始自体はeven analyticityから直ちに従う。本節で記録する実質的情報は、そのexplicit quadratic coefficientである。

## 展開3.1（OB-1：explicit local quadratic coefficient）

第2節の仮定の下で、

\[
W_\delta-W_0=-m\delta^2\left[h''(t)x_0^T+x_0h''(t)^T+2h'(t)h'(t)^T\right]+O(\delta^4),
\tag{3.1}
\]

従って

\[
\boxed{\lVert W_\delta-W_0\rVert_{\mathrm{op}}=O(\delta^2)}.
\tag{3.2}
\]

### 証明

holomorphicityとreal symmetryから

\[
x_\delta=x_0-\frac{\delta^2}{2}h''(t)+O(\delta^4),\qquad y_\delta=-\delta h'(t)+O(\delta^3).
\]

これを \(W_\delta=2m(x_\delta x_\delta^T-y_\delta y_\delta^T)\) に代入すれば式 (3.1) を得る。 \(\square\)

### 注3.2

OB-1の役割は、単なる収束ではなくlocal collision rate \(O(\delta^2)\) を与えることである。次節のcontinuous-output obstruction自体にはこのrateは不要であり、rateはlocally Lipschitz observableやspectral marginの定量化に用いる。

# 4. OB-2：Continuous Separation Obstruction

以下はWeil-specificな独立定理ではなく、topological statementとquantitative collision rateを分離するために記録する初等的なcontinuity consequenceである。

## 観察4.1（OB-2：continuous outputに対するuniform-gap obstruction）

\(W_\delta\to W_0\) とし、有限次元ノルム空間 \(Y\) への写像 \(F\) が \(W_0\) で連続なら、

\[
F(W_\delta)\to F(W_0).
\tag{4.1}
\]

従って任意の十分小さい \(\delta_0>0\) に対し

\[
\boxed{\inf_{0<|\delta|<\delta_0}\lVert F(W_\delta)-F(W_0)\rVert_Y=0}.
\tag{4.2}
\]

### 証明

連続性の直接の帰結である。 \(\square\)

### 注4.2

この命題にholomorphicity、quadratic rate、rank-two structure、Weil-specific structureは不要である。

## 系4.3（locally Lipschitz observable）

さらに \(F\) が \(W_0\) の近傍でlocally Lipschitzなら、OB-1と合わせて

\[
\boxed{\lVert F(W_\delta)-F(W_0)\rVert_Y=O(\delta^2)}.
\tag{4.3}
\]

従って continuity は \(o(1)\)、local Lipschitz + OB-1 は \(O(\delta^2)\) を与える。

## 系4.4（fixed trace moments）

任意の固定整数 \(k\ge1\) に対し

\[
\operatorname{tr}(W_\delta^k)=\operatorname{tr}(W_0^k)+O(\delta^2).
\tag{4.4}
\]

この結論は固定された有限個のmomentについてのみ適用する。

## 4.5 OB-1とOB-2の論理的役割

\[
\boxed{\begin{array}{lll}
\text{OB-1}&W_\delta-W_0=O(\delta^2)&\text{local rate},\\
\text{OB-2}&W_\delta\to W_0,\ F\text{ continuous}&\text{no depth-uniform output gap},\\
\text{OB-1 + Lipschitz }F&\Delta_F(\delta)=O(\delta^2)&\text{quantitative output rate}.
\end{array}}
\tag{4.5}
\]

OB-2はtopologicalなqualitative statement、OB-1はpair pathに固有のquantitative refinementとして扱う。

# 5. OB-3：Exact Negative Detection with Vanishing Margin

## 5.1 初等rank-two恒等式

### 補題5.1（rank-two determinant identity）

\(x,y\in\mathbb R^d\)、\(x\neq0\) とする。\(e_1=x/\lVert x\rVert\) とし、\(P_{x^\perp}y\neq0\) の場合には

\[
e_2=\frac{P_{x^\perp}y}{\lVert P_{x^\perp}y\rVert},\qquad
y=a e_1+b e_2,\qquad
b=\lVert P_{x^\perp}y\rVert>0.
\tag{5.1}
\]

このとき \(W=2m(xx^T-yy^T)\) の \(\operatorname{span}\{x,y\}\) への制限は

\[
W\big|_{\operatorname{span}\{x,y\}}
=2m\begin{pmatrix}
\lVert x\rVert^2-a^2 & -ab\\
-ab & -b^2
\end{pmatrix},
\tag{5.2}
\]

であり、

\[
\boxed{
\det\left(W\big|_{\operatorname{span}\{x,y\}}\right)
=-4m^2\lVert x\rVert^2\lVert P_{x^\perp}y\rVert^2
}
\tag{5.3}
\]

が成り立つ。

### 証明

式 (5.2) の \(2\times2\) determinantを直接計算すればよい。さらに

\[
\operatorname{span}\{x,y\}^{\perp}\subset\ker W
\]

であるため、非零固有値はこの作用部分空間上に限られる。 \(\square\)

## 5.2 非退化pairの局所固有値

衝突点における \(x_0=h(t)\) に対し

\[
P_\perp:=P_{x_0^\perp}
\tag{5.4}
\]

と書く。

### 定理5.2（OB-3：negative directionと局所spectral margin）

第2節の仮定に加えて

\[
\boxed{x_0\neq0,\qquad P_\perp h'(t)\neq0}
\tag{5.5}
\]

を仮定する。このとき、ある \(\delta_0>0\) が存在して

\[
0<|\delta|<\delta_0
\tag{5.6}
\]

ならば \(W_\delta\) はただ一つの負固有値を持つ。その負固有値を \(\lambda_-(\delta)\) とすると、

\[
\boxed{
\lambda_-(\delta)
=-2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4)
}
\tag{5.7}
\]

である。従って

\[
n_-(W_\delta)=1,\qquad n_-(W_0)=0,
\tag{5.8}
\]

かつ

\[
\boxed{\chi_-(W_\delta)=1,\qquad \chi_-(W_0)=0.}
\tag{5.9}
\]

ここで「generic branch」という語は、局所jet条件
\[
x_0\neq0,\qquad P_\perp h'(t)\neq0
\]
を満たすnondegenerate branchを指すだけである。実在のzeta zero集合上での統計的・測度論的・数論的genericityを主張しない。

### 証明

OB-1から

\[
x_\delta=x_0+O(\delta^2),\qquad y_\delta=-\delta h'(t)+O(\delta^3),
\]

従って

\[
P_{x_\delta^\perp}y_\delta=-\delta P_\perp h'(t)+O(\delta^3).
\tag{5.10}
\]

十分小さい非零 \(\delta\) では \(x_\delta\neq0\) かつ \(P_{x_\delta^\perp}y_\delta\neq0\) である。補題5.1より作用部分空間上のdeterminantは負なので、正・負固有値が一つずつ存在する。正固有値を \(\lambda_+(\delta)\) とすると

\[
\lambda_+(\delta)=2m\lVert x_0\rVert^2+O(\delta^2).
\]

補題5.1と (5.10) を用いて \(\lambda_+\lambda_-\) を評価し、\(\lambda_+\) で割れば (5.7) を得る。 \(\square\)

## 5.3 Exact negative detection and vanishing geometric margin

定理5.2より、negative directionの存在は各固定された十分小さい非零depthでexactに検出できる。しかしbinary output differenceがdepth-independentなgeometric robustnessを意味するわけではない。

定義 (2.13) より

\[
\mu_-(W_\delta)=\operatorname{dist}_{\mathrm{op}}(W_\delta,\operatorname{PSD}_d)=|\lambda_-(\delta)|,
\]

従って

\[
\boxed{
\mu_-(W_\delta)
=2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4)
}
\tag{5.11}
\]

であり、

\[
\boxed{\mu_-(W_\delta)\to0\qquad(\delta\to0).}
\tag{5.12}
\]

従って次の三事実を混同しない。

\[
\boxed{
\begin{array}{ll}
W_\delta\neq W_0 & \text{state-level distinction},\\[1mm]
\chi_-(W_\delta)\neq\chi_-(W_0) & \text{discontinuous exact negative detection},\\[1mm]
\mu_-(W_\delta)\to0 & \text{vanishing geometric robustness margin}.
\end{array}}
\tag{5.13}
\]

さらに第4節のcontinuous observable \(F\) については \(F(W_\delta)\to F(W_0)\) である。

> **図3 挿入位置：Exact negative detection with vanishing margin**  
> 横軸をsigned depth \(\delta\)、縦軸をemerging negative eigenvalue \(\lambda_-(\delta)\) とする。generic branch
> \[
> x_0\neq0,\qquad P_\perp h'(t)\neq0
> \]
> の下で、\(\delta\neq0\) では \(\chi_-=1\)、\(\delta=0\) では \(\chi_-=0\) である一方、
> \[
> \mu_-(W_\delta)=|\lambda_-(\delta)|\sim C\delta^2\to0
> \]
> を同一図中で示す。図中に「generic \(q=0\) branch」を明記し、§5.4のhigher-order branches \(\delta^6,\delta^{10},\ldots\) は別分類であり本曲線には含めないことを注記する。

## 5.4 Higher-order transverse-jet classification

定理5.2はgeneric branch \(P_\perp h'(t)\neq0\) を扱った。本節では \(x_0\neq0\) を保ったままgeneric transverse first derivativeが消える場合を分類する。

### 定義5.4（transverse component）

\(x_0\neq0\) とする。十分小さい \(\delta\) では \(x_\delta\neq0\) なので

\[
r(\delta):=P_{x_\delta^\perp}y_\delta
=\left(I-\frac{x_\delta x_\delta^T}{\lVert x_\delta\rVert^2}\right)y_\delta
\tag{5.14}
\]

を定義する。\(x_\delta\) はeven analytic、\(y_\delta\) はodd analyticであるためprojectionもeven analyticであり、

\[
\boxed{r(-\delta)=-r(\delta)}.
\tag{5.15}
\]

従って \(r\) はodd analytic vector-valued functionである。このoddness、したがって後述する \(4q+2\) parity classificationはstanding real-symmetry assumption (2.5) に本質的に依存する。

### 定理5.5（Higher-order transverse-jet theorem）

第2節のholomorphicityおよびreal-symmetry仮定
\[
h(\bar z)=\overline{h(z)}
\]
の下で、さらに \(x_0\neq0\) を仮定する。

#### Case I: \(r\not\equiv0\)

odd analyticityにより、一意な整数 \(q\ge0\) と非零ベクトル \(w\in\mathbb R^d\) が存在して

\[
\boxed{r(\delta)=\delta^{2q+1}w+O(\delta^{2q+3})}
\tag{5.16}
\]

と書ける。このとき十分小さい非零 \(\delta\) に対して \(W_\delta\) はただ一つの負固有値を持ち、

\[
\boxed{
\lambda_-(\delta)
=-2m\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4})
}
\tag{5.17}
\]

が成り立つ。従ってnegative spectral marginのleading orderは

\[
\boxed{4q+2\in\{2,6,10,14,\ldots\}.}
\tag{5.18}
\]

特に \(\delta^4,\delta^8,\ldots\) は、この \(x_0\neq0\) analytic branchではleading orderとして現れない。

#### Case II: \(r\equiv0\)

\(r(\delta)\equiv0\) なら \(y_\delta\parallel x_\delta\) であり、ある実解析関数 \(a(\delta)=O(\delta)\) により

\[
y_\delta=a(\delta)x_\delta
\]

と書ける。従って

\[
W_\delta=2m(1-a(\delta)^2)x_\delta x_\delta^T\succeq0
\tag{5.19}
\]

が十分小さい \(\delta\) で成立し、negative eigenvalueは生じない。

### 証明

\(r\) はodd analyticなので、\(r\not\equiv0\) なら最初の非零Taylor次数は奇数 \(2q+1\) である。従って

\[
\lVert r(\delta)\rVert^2=\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4}).
\tag{5.20}
\]

補題5.1より

\[
\det\left(W_\delta\big|_{\operatorname{span}\{x_\delta,y_\delta\}}\right)
=-4m^2\lVert x_\delta\rVert^2\lVert r(\delta)\rVert^2.
\tag{5.21}
\]

OB-1より
\[
\lVert W_\delta-W_0\rVert_{\mathrm{op}}=O(\delta^2),
\]
一方 \(W_0=2mx_0x_0^T\) の最大固有値は \(2m\lVert x_0\rVert^2>0\) である。Weylの固有値perturbation boundから
\[
\left|\lambda_{\max}(W_\delta)-2m\lVert x_0\rVert^2\right|
\le \lVert W_\delta-W_0\rVert_{\mathrm{op}}
=O(\delta^2).
\]
十分小さい \(\delta\) では、この固有値がactive subspace上のpositive eigenvalue \(\lambda_+(\delta)\) である。従って
\[
\lambda_+(\delta)=2m\lVert x_0\rVert^2+O(\delta^2).
\]
よって \(\lambda_-=\det/\lambda_+\) から (5.17) を得る。Case IIはcollinearityから直ちに (5.19) を得る。 \(\square\)

### 系5.6（generic case）

もし \(P_\perp h'(t)\neq0\) なら

\[
r(\delta)=-\delta P_\perp h'(t)+O(\delta^3),
\]

従って \(q=0\) であり、定理5.5は定理5.2を再現する。

### 系5.7（first transverse derivative vanishes）

\[
P_\perp h'(t)=0
\]

なら \(q=0\) は起こらない。従って

\[
\boxed{
\begin{cases}
r\equiv0,&\text{negative directionなし},\\[1mm]
r\not\equiv0,&\lambda_-(\delta)=O(\delta^6)\text{以上の高次で出現}.
\end{cases}}
\tag{5.22}
\]

従って \(P_\perp h'(t)=0\) だけからnegative directionの消失を結論してはならない。

### 注意5.7a（parity lawのreal-symmetry依存）

定理5.5はanalytic matrix family一般のorder classificationではない。standing assumption \(h(\bar z)=\overline{h(z)}\) を外すと、\(x_\delta\) のevennessおよび \(y_\delta\) のoddnessは一般には失われ、\(r(\delta)\) がoddである必要もない。従って \(\operatorname{ord}_0r=2\) のようなeven orderも許され得て、\(\lambda_-(\delta)\asymp-\delta^4\) 等を一般には排除できない。

したがって \(2,6,10,14,\ldots\) というleading-order seriesはreal-symmetric analytic model classにおけるparity lawである。

### 例5.8（次数系列のsharpness）

任意の整数 \(q\ge0\) に対して次数 \(4q+2\) は実際に実現可能である。\(d=2\) とし

\[
h(z)=e_1+e_2(z-t)^{2q+1}
\tag{5.23}
\]

と置く。このとき \(x_\delta=e_1\)、\(y_\delta=(-1)^{q+1}\delta^{2q+1}e_2\) なので

\[
W_\delta=2m\begin{pmatrix}1&0\\0&-\delta^{4q+2}\end{pmatrix},
\]

従って

\[
\boxed{\lambda_-(\delta)=-2m\delta^{4q+2}.}
\tag{5.24}
\]

よって \(2,6,10,14,\ldots\) の系列はreal-symmetric analytic model class内でsharpである。ただし実際のWeil evaluation familyが全ての \(q\) を実現するとは主張しない。

### 注意5.9（\(x_0=0\) branchとの分離）

定理5.5は \(x_0\neq0\) を本質的に用いる。\(x_0=0\) ではpositive eigenvalue自体も0へ縮退するので、次節で独立に扱う。

# 6. $x_0=0$ のdegenerate regime

定理5.2は $x_0\neq0$ を仮定する。$x_0=0$ の場合は、衝突点に正のrank-one方向が存在しないため、同じ射影係数を用いてはならない。本節ではこの場合を独立に扱う。

## 命題6.1（vanishing-base-vector regime）

第2節の仮定に加えて

\[
\boxed{
x_0=0,
\qquad
h'(t)\neq0
}
\tag{6.1}
\]

を仮定する。このとき

\[
x_\delta=O(\delta^2),
\qquad
y_\delta=-\delta h'(t)+O(\delta^3),
\tag{6.2}
\]

したがって

\[
\boxed{
W_\delta
=-2m\delta^2h'(t)h'(t)^T
+O(\delta^4)
}
\tag{6.3}
\]

が成り立つ。さらに、ある $\delta_0>0$ が存在して、$0<|\delta|<\delta_0$ では $W_\delta$ はただ一つの負固有値を持ち、

\[
\boxed{
\lambda_-(\delta)
=-2m\lVert h'(t)\rVert^2\delta^2
+O(\delta^4)
}
\tag{6.4}
\]

となる。

### 証明

展開3.1の証明で用いたTaylor展開に $x_0=0$ を代入すれば (6.2) を得る。従って $x_\delta x_\delta^T=O(\delta^4)$ かつ

\[
y_\delta y_\delta^T
=\delta^2h'(t)h'(t)^T+O(\delta^4),
\]

であり、式 (2.8) から (6.3) が従う。さらに

\[
\delta^{-2}W_\delta
\longrightarrow
-2m h'(t)h'(t)^T
\]

である。右辺は単純な負固有値 $-2m\lVert h'(t)\rVert^2$ を持つ。固有値の連続性と (6.3) のremainder評価から (6.4) を得る。また $W_\delta$ はpositive rank-one matrixとnegative rank-one matrixの差なので負固有値数は高々1であり、上の負固有値の存在と合わせてexactly oneとなる。$\square$

### 注意6.2（higher-order degenerate regime）

\(x_0=0\) かつ \(h'(t)=0\) の場合には、leading orderは \(h''(t)\)、\(h'''(t)\) 以降に依存する。このhigher-order degenerate regimeは本稿では一般分類しない。従って命題6.1の係数をこの場合へ形式的に適用してはならない。

leading PSD termだけからnegative directionが存在しないと結論してはならない。例えば \(d=2\) で
\[
h(z)=e_1(z-t)^2+e_2(z-t)^3
\]
とすると
\[
h(t)=0,\qquad h'(t)=0,\qquad h(t-i\delta)=-\delta^2e_1+i\delta^3e_2,
\]
したがって
\[
W_\delta=2m
\begin{pmatrix}
\delta^4&0\\
0&-\delta^6
\end{pmatrix},
\qquad
\boxed{\lambda_-(\delta)=-2m\delta^6.}
\]

一般に \(h''(t)\neq0\) かつ \(P_{h''(t)^\perp}h'''(t)\neq0\) なら
\[
\lambda_-(\delta)
=
-\frac{m}{18}
\left\|P_{h''(t)^\perp}h'''(t)\right\|^2
\delta^6+O(\delta^8).
\]
ここではこのbranchの完全なhigher-order classificationまでは行わない。

---

# 7. OB-4：Finite-Dimensional Regularity Consequence

OB-4は普遍的な不可観測性原理ではなく、有限次元の連続構成に対する一般的なcontinuity consequenceとして記録する。

## 命題7.1（OB-4：有限次元regularity consequence）

\(E_\delta\) を有限次元evaluation dataとし、

\[
E_\delta\to E_0\qquad(\delta\to0)
\]

と仮定する。有限次元matrix familyが \(E_0\) の近傍で連続な構成写像 \(\mathcal W\) により

\[
W_\delta=\mathcal W(E_\delta)
\]

と与えられるなら \(W_\delta\to W_0\) である。従って任意の \(W_0\)-continuous finite-dimensional matrix observable \(F\) に対し

\[
F(W_\delta)\to F(W_0),
\]

であり、collision近傍にdepth-independentなpositive output separationは存在しない。

### 証明

連続写像の合成による極限保存の直接の帰結である。 \(\square\)

### 注意7.2（Weil setting）

本稿のpair blockでは

\[
E_\delta=(h(t-i\delta),h(t+i\delta))
\]

である。holomorphicityは \(E_\delta\to E_0\) を保証する十分条件であり、式 (2.8) はevaluation dataの多項式なので連続である。

### 注意7.3（scope）

OB-4は、\(W_0\) で不連続なdetector、parameter依存のdetector、changing dimension、infinite-dimensional operator limit、追加算術入力、interacting multi-pair system等を排除しない。従って全Weil法、Anthropic法全体、全非線形observable、または全算術的observableに対するabsolute no-goとして用いない。

## 表1：OB-1〜OB-4の役割

| 結果 | 主な仮定 | 結論 | 役割 |
|---|---|---|---|
| OB-1 | fixed finite \(d\)、holomorphic real-symmetric \(h\)、single-pair block | \(W_\delta-W_0=O(\delta^2)\) | local collision rate |
| OB-2 | \(W_\delta\to W_0\)、\(F\) continuous | depth-uniform positive output gapなし | topological separation obstruction |
| OB-2定量系 | OB-1 + local Lipschitz \(F\) | output difference \(O(\delta^2)\) | quantitative rate |
| OB-3 | \(x_0\neq0\)、\(P_\perp h'(t)\neq0\) | exact negative detection、\(\mu_-\sim C\delta^2\) | generic detector / margin separation |
| OB-3 higher-order extension | \(x_0\neq0\)、\(r(\delta)\not\equiv0\)、\(\operatorname{ord}_0 r=2q+1\) | \(\lambda_-\sim-2m\lVert w\rVert^2\delta^{4q+2}\) | transverse-jet classification |
| OB-4 | finite-dimensional continuous construction | continuous observableのgap消失 | general continuity consequence |

# 8. 三つのinformation-loss / detection regime

zero-side informationの扱われ方は一種類ではない。本稿では、少なくとも次の三つを区別する。

## 表2：Erasure / Compression Loss / Vanishing-Margin Detection

| Type | 情報の状態 | 典型的写像 | 本稿での意味 |
|---|---|---|---|
| Type I — Erasure | depth情報そのものがencoding前後で消える | \((\delta,\gamma)\mapsto\gamma\) | 後段から \(\delta\) を復元できない |
| Type II — Compression Loss | full matrix内にはgeometryが残るが、粗いcertificate interfaceで捨てられる | aggregate matrix \(\to\) inertia/rank/trace interface | certificateが使用しないgeometryは失われ得る |
| Type III — Vanishing-Margin Detection | discontinuous detectorではexactに検出できるが、その判定境界までの距離が0へ縮む | \(W_\delta\mapsto(\chi_-(W_\delta),\mu_-(W_\delta))\) | generic branchでは \(\mu_-\asymp\delta^2\)、higher-order transverse branchでは \(\mu_-\asymp\delta^{4q+2}\)；いずれもexact detectionとvanishing marginを分離 |

Type IIは、full matrixに情報が存在しないという主張ではない。またcoarse certificateが数学的に無効であるという意味でもない。

Type IIIのgeneric \(q=0\) branchでは

\[
\chi_-(W_\delta)=1\qquad(0<|\delta|<\delta_0),
\]

である一方、

\[
\mu_-(W_\delta)=2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4)\to0.
\tag{8.1}
\]

§5.4のhigher-order transverse branchでは、同じexact detectionが保たれる場合でも

\[
\mu_-(W_\delta)
=
2m\lVert w\rVert^2\delta^{4q+2}
+
O(\delta^{4q+4})
\]

と、より高次でmarginが消失し得る。

従って本稿の中心的区別は、旧版の二分法ではなく

\[
\boxed{
\text{state distinction}\ ;\ 
\text{discontinuous exact detection}\ ;\ 
\text{vanishing geometric margin / continuous no-gap}
}
\tag{8.2}
\]

という三層構造である。

\[
\text{no depth-uniform continuous separation}\neq\text{nonexistence of off-line structure}
\tag{8.3}
\]

であることにも注意する。

> **図4 挿入位置：information-flow classification**  
> single-pair layer、aggregate/certificate layer、continuous-observable layerを分離して描く。negative-presence detector \(\chi_-\) とgeometric margin \(\mu_-\) を別ノードにする。

# 9. 複数pair：exact direct-sum case

本節で定理化するのは、相互作用のないexact direct-sumだけである。$\gamma_j$ が離れているという定性的条件だけからdirect sumまたは近似直交性を結論することはしない。

## 定理9.1（finite exact direct-sum extension）

有限集合 $J$ の各 $j\in J$ について、有限次元block $W_{\delta_j}^{(j)}$ が第2節および定理5.2の仮定を満たすとする。すなわち

\[
x_0^{(j)}\neq0,
\qquad
P_{\perp,j}h_j'(t_j)\neq0,
\qquad
m_j>0.
\tag{9.1}
\]

exact direct-sum matrixを

\[
\boxed{
W(\boldsymbol\delta)
:=\bigoplus_{j\in J}W_{\delta_j}^{(j)}
}
\tag{9.2}
\]

と定義する。このとき各 $j$ について、ある $\delta_{0,j}>0$ が存在し、

\[
0<|\delta_j|<\delta_{0,j}
\]

ならば対応するblockはただ一つの負固有値を持ち、

\[
\boxed{
\lambda_{-,j}(\delta_j)
=-C_j\delta_j^2+O(\delta_j^4)
}
\tag{9.3}
\]

となる。ここで

\[
\boxed{
C_j
:=2m_j
\lVert P_{\perp,j}h_j'(t_j)\rVert^2
>0
}
\tag{9.4}
\]

である。

さらに、direct sumのスペクトルは各blockのスペクトルの重複度付き和集合なので、十分小さい $\boldsymbol\delta$ に対し

\[
n_-\bigl(W(\boldsymbol\delta)\bigr)
=\#\{j\in J:\delta_j\neq0\}
\tag{9.5}
\]

である。ただし各非零 $\delta_j$ は対応するlocal neighborhood内にあるものとする。

### 証明

式 (9.3)、(9.4) は各blockへの定理5.2の適用である。direct sumの固有値は各blockの固有値の和集合であり、inertiaは加法的なので式 (9.5) が従う。$\square$

### 系9.2（direct-sum negative spectral margin）

少なくとも一つの $\delta_j\neq0$ があるとき、off-line blocksに対応する負固有値の最小絶対値を

\[
\mu(\boldsymbol\delta)
:=\min_{j:\delta_j\neq0}
|\lambda_{-,j}(\delta_j)|
\tag{9.6}
\]

とする。有限個の固定blockについて $\max_j|\delta_j|\to0$ とすれば、

\[
\mu(\boldsymbol\delta)
\asymp
\min_{j:\delta_j\neq0}C_j\delta_j^2.
\tag{9.7}
\]

従って、direct-sum全体の最も弱いnegative spectral marginは、最も浅い非退化blockによって支配される。

### 注意9.3（Future Work）

実際のaggregate matrixでは異なるpair contributionが同じambient spaceに作用し、cross termsまたはevaluation-vector dependenceを持ち得る。本稿は

- sufficiently separated pairs、
- approximately orthogonal pairs、
- nearby/interacting pairs、

のいずれについても定量的分離条件を証明していない。これらをdirect-sum theoremへ含めず、interacting multi-pair analysisをFuture Workとする。具体的な研究課題は§12.7 Track Bで整理する。

---

# 10. 先行研究との関係

## 10.1 Weil quadratic formとAlpöge–Furman / Anthropic formalization

Weilの明示公式は、適切なtest-function class上の二次形式の正値性とRHを結び付ける [3]。本稿が扱う $W_\delta$ は、その全体を置き換えるものではなく、現行formalizationの `blockA` / `pair_term` から抽出したsingle reflection-pair contributionの局所parameterizationである。

Alpöge–Furman 2026 [1] は、有限次元zero-side matrixを臨界線上のpositive contributionとoff-line pair contributionへ分け、rank、positive index、traceおよびFrobenius normを用いる。Anthropicの現行Lean 4 formalization [2] は同論文の主要定理と線形代数・解析入力を機械検証可能な形で記録する。

原論文のindex/rank argumentは、near-critical pairのevaluation vectorsが近依存になる場合を含め、off-line depthをexactに使用しない形で設計されている。本稿の結果はそのexact argumentを無効化するものではない。本稿が示すのは、同じsingle-pair dataに対して、continuous output separationとnegative-presence detectionを支えるgeometric marginがcollisionで消失するという別の局所的性質である。

## 10.2 Bombieriの有限切断

Bombieri [4] はWeil quadratic functionalの有限切断と固有値を研究し、RHが有限個のoff-line zeroによってのみ破れるという仮定の下で、十分大きい切断の負固有値数がRHを外れる零点数の半分になることを示した。

従って、off-line zerosとnegative inertiaの大域的対応そのものは既知背景であり、本稿はその発見を主張しない。Bombieriの結果は十分大きい有限切断におけるglobal countを扱うのに対し、本稿は現行zero-side constructionから抽出した一つのreflection-pair contributionについて、$\delta\to0$ collision limitにおけるexplicit eigenvalue coefficient、geometric-margin collapse、およびreal-symmetric higher-order transverse-jet classificationを局所的に記述する。両者は同じ定理ではない。定理5.5の $4q+2$ classificationについてもhistorical priorityは主張しない。

有限個のoff-line exceptionがすべて非零depthを持つならば、その有限集合上で

\[
\delta_{\min}
:=\min_\rho
\left|\Re\rho-\frac12\right|>0
\]

が従う。これはBombieriの独立した明示仮定としてではなく、「有限個の非零実数の集合」の基本的性質から従う推論である。

## 10.3 Higher-level correlations

Rudnick–Sarnak [5] の $n$-level correlation framework、およびそれをsemidefinite programmingと組み合わせたGonçalves–de Laat–Leijenhorst [6] は、零点multiplicityに関する強い結果を与える。ただし [6] が用いる該当frameworkはGRHを仮定している。

従って、今回検討した直接的routeでは、ordinary $R_3$ またはhigher-level correlation resultを、そのまま無条件のhorizontal detectorとして使用することはできない。これはhigher-level correlation研究一般の否定ではなく、今回監査した入力経路の条件に関する限定的判断である。

なお、Lamzouri [9] は2026年9月に、同じ67.25%級のsimple-critical-line proportionに対する別の、より直接的な無条件証明を与えている。Lamzouriの証明はAlpöge–Furmanのfinite-dimensional matrix frameworkをHilbert-space inequalityで置き換え、Montgomery型pair-correlation inputを直接用いる。本稿はその別機構を解析するものではなく、Alpöge–Furman / Anthropic formalizationに現れるfinite-dimensional zero-side pair structureを局所的に解析する。従って本稿のlocal observability analysisをLamzouriの証明へ自動的に移植できるとは主張しない。

## 10.4 de Branges / Kreinの広い背景

de Branges spaces [7]、Krein型の不定値構造および正定値関数の延長問題 [8] は、entire functions、spectral theory、正定値性・不定値性の関係を扱う広い理論的背景を与える。

ただし本稿のOB-1〜OB-4は、これらの理論から特定の定理を引用して証明するものではない。本稿では、確認できていない先行定理をde BrangesまたはKreinへ帰属させず、一般的背景としてのみ言及する。

## 10.5 Noveltyに関する限定

本調査範囲では、式 (5.7) および定理5.5のhigher-order classification（特に式 (5.17)）と同一の局所定式化を確認できなかった。しかし、この調査は先行研究の完全な不存在を証明するものではなく、本稿はhistorical priorityを主張しない。

---

# 11. Failure Ledger

Failure Ledgerは、探索中に検討された経路を、現在の判断と適用範囲とともに保存するための記録である。「CLOSED」または「棄却」は、記載されたaudited classまたは提案形に限られ、隣接する全手法へ自動的に拡張されない。

## 表3：Failure Ledger

| Route | Status | 現在の判断・限定理由 |
|---|---|---|
| support (>1) extension | PARKED | 現在のprime-side diagonal evaluationを超え、Hardy–Littlewood型の強いprime-correlation inputが必要になる。原理的不可能性は主張しない。 |
| scalar bandwidth-one linear certificate improvements | CLOSED within audited class | PairCeilingは監査されたscalar linear certificate classにのみ適用する。付属Lean資料 [2] の約0.6818287を含むboundには、明示されたstability correctionとenclosure hypothesisが伴う。約0.682を全手法の上限として使用しない。 |
| finite same-block higher trace moments as a uniform detector | CLOSED for this role | 各固定次数trace momentはpolynomialでlocally Lipschitzなので、OB-1と系4.3–4.4により差は $O(\delta^2)$。OB-2単独からもuniform positive gapが存在しないことは従う。ただしhigher tracesまたはnonlinear observables一般の無効性は意味しない。 |
| ordinary $R_3$ as unconditional RH-free input | CLOSED for the inspected route | 今回検討したRudnick–Sarnak / Gonçalves–de Laat–Leijenhorst frameworkはGRH条件付き。higher-level correlation一般へのno-goではない。 |
| simple continuous 3-cycle detector | CLOSED in audited form | audited formが有限次元evaluation dataの連続関数として構成される限り、同じcollision no-gapに従う。非連続・極限依存・別入力を含む構成は対象外。 |
| same-zero Gram $B=\sum uu^*$ from the ordinary one-variable Weil formula | WITHDRAWN as proposed | ordinary one-variable Weil formulaから、提案されたsame-zero positive Gramを無条件に同定する手順は成立しない。旧同定を使用しない。 |
| nonvanishing finite-magnitude spectral gap at collision | REJECTED | 負固有値は存在し得るが、$\lambda_-(\delta)\to0$ と連続的に消失する。jumpするのはinertia countであり、有限大のeigenvalue gapではない。 |
| Hermitian/real-symmetric encoding erases $\delta$ immediately | WITHDRAWN | $\delta$ は $y_\delta$ およびnegative signatureとしてsingle-pair ZeroSideに残り得る。情報消失が起こるなら、その後のcompression/interfaceまたはzero-marginの問題として区別する。 |
| horizontal energy uniformly counts off-line zeros | REJECTED without depth lower bound | 一pairのdepth-sensitive energyは典型的に $O(\delta^2)$ であり、$\delta\to0$ を許すと一pair当たりの一様な正の下限がない。depth lower boundなしにoff-line countを一様制御できない。 |
| first-order transverse degeneracy interpreted as complete sign loss | WITHDRAWN | 旧理解では \(P_\perp h'(t)=0\) からnegative direction消失を推論したが誤り。外部cold reviewの指摘を契機に再計算し、\(r(\delta)=P_{x_\delta^\perp}y_\delta\) のodd analyticityから \(\lambda_-\sim-2m\lVert w\rVert^2\delta^{4q+2}\) を得た。完全collinear \(r\equiv0\) の場合のみnegative branchが消える。 |

### 研究方法上の注記

棄却された仮説を結果だけ消去すると、同じ誤同定が別の表現で復活し得る。本稿では、壊れた仮説も適用範囲と失敗理由を付して保存する。ただしFailure Ledger自体を、列挙されていない全構成へのno-go listとして用いてはならない。

---

# 12. 限界・uniformity scope・未解決点

## 12.1 固定有限次元・固定collision ordinate

本稿の漸近結果は、固定された有限次元 \(d\)、固定されたcollision ordinate \(t\)、固定されたholomorphic evaluation family \(h\) に対するlocal resultである。

本稿は

\[
d\to\infty,\qquad |t|\to\infty,\qquad x_0\to0
\]

を \(\delta\to0\) と同時に取るjoint limitについて、一様な漸近またはlimit interchangeを主張しない。

## 12.2 \(x_0\to0\) に関するscope

定理5.2および定理5.5の \(x_0\neq0\) branchでは

\[
\lambda_+(\delta)=2m\lVert x_0\rVert^2+O(\delta^2)
\]

を用いる。従ってremainder定数や許容local radius \(\delta_0\) が \(x_0\to0\) に一様であるとは主張しない。\(x_0=0\) branchは第6節で独立に扱う。

## 12.3 \(t\to\infty\) に関するscope

Taylor remainder、\(h^{(k)}(t)\)、\(P_\perp h'(t)\)、local radius等は一般に \(t\) に依存する。本稿では

\[
\inf_{|t|\ge T}\lVert P_\perp h'(t)\rVert>0
\]

のようなglobal transverse nondegeneracyを仮定・導出しない。

## 12.4 Dimension scope

\(d=1\) かつ \(x_0\neq0\) なら \(P_\perp=0\) なので、定理5.2のgeneric transverse branchは成立しない。従ってこのbranchは事実上 \(d\ge2\) を要求する。ただし本稿全体が \(d\ge2\) を要求するわけではなく、第6節のvanishing-base-vector regime等は別である。

## 12.5 Numerical robustness

本稿はgeometric spectral marginの漸近次数を示すが、floating-point error、noise model、condition number、有限precision thresholdを定量化しない。

## 12.6 Arithmetic scope

本稿はprime sideの新しい評価を与えず、off-line zeroの存在を仮定または証明しない。従ってcritical-line proportionの改善、新しいzero count bound、RHへの含意は得られない。

## 12.7 Next Research Agenda

V1.0の定理を拡張する次段階は、次の順序で整理する。以下は**未解決問題の研究計画**であり、V1.0の定理・実証結果には含めない。

### Track A — actual taper familyにおけるjet strataのnon-vacuity

現行zero-side constructionの実際のevaluation familyは

\[
h_{P,T}(z)
=
\left(
\widehat\phi(z-\tau_k)
\right)_{k<d},
\qquad
\tau_k=T+k\frac{2\pi}{L},
\]

という、同一の \(\widehat\phi\) の平行移動からなる制約された族である。これはTheorem 5.5のholomorphicかつreal-symmetricな仮定クラスに含まれるため、**分類定理そのものはこのactual familyにも適用される**。

未解決なのは、Theorem 5.5のhigher-order strataがこの制約族で実際にnonemptyか、特に

\[
q\ge1
\]

が実現可能かである。

\(x_0=h(t)\neq0\) の下で一次transverse degeneracy

\[
P_{h(t)^\perp}h'(t)=0
\]

は

\[
h'(t)=\alpha h(t)
\]

と同値であり、成分ごとには

\[
\widehat\phi'(t-\tau_k)
=
\alpha\,\widehat\phi(t-\tau_k)
\qquad(k<d)
\]

という同時jet条件を要求する。次の課題は、この条件およびhigher transverse jetsの消失条件を、compactly supported taperから生じる \(\widehat\phi\) と等間隔grid \(\tau_k\) の構造の下で特徴付けることである。

具体的には：

- actual taper familyでgeneric \(q=0\) branchがどの条件で成立するかを特徴付ける。
- \(q\ge1\) のhigher-order branchが実現可能か、不可能ならそのobstructionを証明する。
- \(x_0=0\)、\(h'(t)=0\) branchをactual familyの制約下で分類する。
- 「generic」はlocal jet nondegeneracyのみを意味し、actual zeta zeros上の統計的genericityを意味しないことを維持する。
- off-line zeroの存在自体は仮定も証明もしない。従って本課題はconditional local geometryのnon-vacuityを問うものである。

### Track B — single pairからaggregate spectrumへのspectral interaction

次に、

\[
A_\delta
=
A_{\mathrm{on}}
+
\sum_j W_j(\delta_j)
\]

において、single-pair negative branchが同じambient space上の他のpair contributionやbackgroundの存在下でどの条件なら保存されるかを調べる。

主要課題は：

- pair subspaces間のangle、approximate orthogonality、separationからapproximate direct sumを導く誤差評価。
- background \(B\) を含む
  \[
  A_\delta=B+W_\delta
  \]
  に対し、negative branchを保存するspectral-gap / subspace-angle / perturbative条件の導出。
- nearby/interacting pairsに対するeigenvalue splittingとmargin degradationの定量化。
- local pair asymptoticとaggregate certificate interfaceの間で失われる情報の定量化。
- exact direct sum §9から一般aggregateへ移る際に、どの追加仮定が最小限必要かの同定。

### Track C — changing dimension, large ordinate, and operator limits

fixed \(d,t,h\) の局所分類を、

\[
d=d(\delta)\to\infty,\qquad
|t|\to\infty,\qquad
\delta\to0
\]

のjoint regimeへ拡張できるかを調べる。

主要課題は：

- Taylor remainderとtransverse jet boundsの \(d,t\) に関するuniformity。
- \(\delta\to0\) と \(d\to\infty\) / \(t\to\infty\) のlimit orderの非可換性。
- finite-dimensional eigenvalue branchがoperator limitでどのtopologyの下に保存されるか。
- \(4q+2\) scalingがchanging-dimension regimeで維持される条件、または別scalingへ遷移する条件。

### Track D — prior art, numerical robustness, and detector realization

Track A–Cと並行して、次を行う。

- Theorem 5.5と同型のlocal jet classificationが、analytic matrix perturbation、transversality、jet geometry、singularity theory、control theory等に既出かを対象限定して調査する。
- noise model、finite precision、condition numberを導入し、
  \[
  \mu_-(W_\delta)
  \]
  と実際のdetector thresholdの関係を定量化する。
- discontinuous exact detectorのconstant output gapとvanishing geometric marginを、numerical decision problemとして区別する。

### Priority

最初の研究対象はTrack Aとする。理由は、Theorem 5.5がactual taper familyにも適用される一方、higher-order branch \(q\ge1\) の**実現可能性 / 不可能性**が現在未解決であり、これがlocal classificationのnon-vacuityを最も直接に決めるからである。

Track Aの結果を受けてTrack Bへ進み、single-pair geometryがaggregate spectrumでどこまで保持されるかを検証する。その後Track Cでfinite-to-infinite observabilityを扱う。Track Dはこれらと並行して進める。

これらの課題はV1.0の定理には含めず、V1.0はそれらの出発点となるfixed finite-dimensional single-pair classificationを提供する。

# 13. 結論：local detector-regularity boundary

本稿で確認したlocal pictureは、単一の「observable / unobservable」という二分法ではない。

定理5.2のnondegenerate branchでは、十分小さい各非零depthで \(W_\delta\neq W_0\) であり、negative-presence detectorにより

\[
\chi_-(W_\delta)=1,\qquad \chi_-(W_0)=0
\]

とexactに区別できる。

しかし、その判定を支えるgeometric marginは

\[
\mu_-(W_\delta)\to0
\]

であり、generic branchでは

\[
\mu_-(W_\delta)
=2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4).
\]

またcontinuous finite-dimensional observableについては \(F(W_\delta)\to F(W_0)\) であり、depth-uniformなpositive output separationは存在しない。

さらにgeneric transverse derivativeが消えてもnegative directionが必ず消えるわけではない。higher transverse jetが存在すれば

\[
\lambda_-(\delta)
=-2m\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4})
\]

というhigher-order branchが生じ、可能なleading ordersは \(2,6,10,14,\ldots\) である。この系列はreal-symmetric analytic model class内でsharpである。

従って本稿のlocal conclusionは

\[
\boxed{\text{exact negative detection can persist while its geometric margin collapses}}
\]

というregularity-dependentな現象として記述するのが適切である。

ここでいうboundaryは、fixed finite-dimensional single-pair local familyにおけるdetector regularity classesの境界である。全Weil構成に対するno-go、arithmetic information一般の不可観測性、interacting multi-pair system、またはinfinite-dimensional limitへの結論には拡張しない。次段階は§12.7に示した通り、actual taper familyでのjet strataのnon-vacuityを最初に検証し、その後aggregate spectral interaction、finite-to-infinite limitへ進む。

# 参考文献

[1] L. Alpöge and N. Furman, *More than two thirds of the zeta zeros are simple and on the critical line*, arXiv:2608.13637, 2026.

[2] Anthropic, `formal-math` repository, `zeta23/` formalization project, audit snapshot `fbdc36bbf17d20af3fd0447c6d1a8a02773c9844`, 2026. Historical standalone companion: `anthropics/zeta-23-lean`.

[3] A. Weil, “Sur les ‘formules explicites’ de la théorie des nombres premiers,” *Meddelanden från Lunds Universitets Matematiska Seminarium*, 1952, 252–265.

[4] E. Bombieri, “Remarks on Weil’s quadratic functional in the theory of prime numbers, I,” *Atti della Accademia Nazionale dei Lincei. Rendiconti Lincei. Matematica e Applicazioni*, Series 9, 11 (2000), no. 3, 183–233.

[5] Z. Rudnick and P. Sarnak, “Zeros of principal \(L\)-functions and random matrix theory,” *Duke Mathematical Journal* 81 (1996), no. 2, 269–322.

[6] F. Gonçalves, D. de Laat, and N. Leijenhorst, “Multiplicity of nontrivial zeros of primitive \(L\)-functions via higher-level correlations,” arXiv:2303.01095v2, 2025.

[7] L. de Branges, *Hilbert Spaces of Entire Functions*, Prentice-Hall, 1968.

[8] M. G. Krein and H. Langer, “Continuation of Hermitian positive definite functions and related questions,” *Integral Equations and Operator Theory* 78 (2014), no. 1, 1–69.

[9] Y. Lamzouri, *A new proof that more than $2/3$ of the zeros of the Riemann zeta function are simple and on the critical line*, arXiv:2609.02882, 2026.

---

# Appendix A. 定理依存関係と版監査表

## A.1 定理依存関係

| 結果 | 主要依存 |
|---|---|
| zero-side bridge | `gammaOf`, `blockA`, `blockA_apply`, `pair_term`, `blockA_decomp`, `paperFT_fk`, `GzGp.phiHat_conj`, `Gz_eq_W` at snapshot `fbdc36bb...` |
| OB-1 | holomorphic real-symmetric evaluation family、single-pair block (2.8)、Taylor expansion |
| OB-2 | path convergence \(W_\delta\to W_0\)、\(F\) のcontinuity |
| Lipschitz corollary | OB-1の \(O(\delta^2)\)、local Lipschitz bound |
| fixed trace moments | Lipschitz corollary、fixed finite degree polynomial map |
| rank-two identity | \(2m(xx^T-yy^T)\) の作用二次元部分空間での代数計算 |
| OB-3 generic branch | OB-1、rank-two identity、\(x_0\neq0\)、\(P_\perp h'(t)\neq0\) |
| geometric margin | OB-3、\(\mu_-(A)=\operatorname{dist}_{op}(A,PSD_d)\) |
| higher-order transverse-jet theorem | \(x_0\neq0\)、odd analyticity of \(r(\delta)\)、rank-two identity |
| vanishing-base-vector proposition | \(x_0=0\)、\(h'(t)\neq0\)、Taylor expansion |
| OB-4 | finite-dimensional continuous construction |
| direct-sum theorem | generic OB-3 applied blockwise、exact direct-sum spectrum |

## A.2 Version 1.0 publication-patch監査

| 監査項目 | 結果 |
|---|---|
| v0.3 Frozenを直接変更していない | PASS — v0.4 Working Draftを経てV1.0 Publication Candidateへ分岐 |
| state / detector / geometric margin / continuous observableを分離 | PASS — §2.4 |
| \(n_-\) をambient robustness尺度として扱わない | PASS — §2.4.2–2.4.3 |
| \(\chi_-\) と \(\mu_-\) を分離 | PASS — §2.4、§5.3 |
| OB-2をcontinuityのみのstatementへ縮小 | PASS — §4 |
| OB-1をlocal quantitative rateへ限定 | PASS — §3、§4.5 |
| 現行zero-side codeとのbridgeを本文で立証 | PASS — §2.3 |
| source bindingを `formal-math @ fbdc36bb...` に固定 | PASS — §2.3 |
| transpose `blockA` と conjugated `Wsummand` を別レイヤーとして区別 | PASS — §2.3.4 |
| generic OB-3に \(x_0\neq0\)、\(P_\perp h'(t)\neq0\) を明示 | PASS — §5.2 |
| generic negative marginを \(\mu_-\sim C\delta^2\) と定義 | PASS — §5.3 |
| \(P_\perp h'(t)=0\Rightarrow\) sign loss という旧誤解を撤回 | PASS — §5.4、Failure Ledger |
| higher-order orders \(4q+2=2,6,10,\ldots\) を証明 | PASS — 定理5.5 |
| sharpness exampleを明示 | PASS — 例5.8 |
| \(x_0=0\) branchを独立regime化 | PASS — §6 |
| fixed \(d,t,h\) とjoint-limit非主張を明記 | PASS — §12 |
| \(d=1\) のgeneric transverse branch不成立を明記 | PASS — §12.4 |
| interacting pairsを定理化していない | PASS — §9.3、§12.7 |
| observabilityという語をdetector classの局所境界に限定 | PASS — §8、§13 |
| RH・absolute no-go・priority claimを排除 | PASS — §1.3、§7.3、§12、§13 |
| Related Worksを現行arXiv / repo基準へ更新 | PASS — §10、参考文献 |
| 図1〜4の仕様文と表1〜3をV1.0本文へ同期 | PASS — 図3・表1・表2をhigher-order classificationまで反映 |
| snapshot `fbdc36bb...` に対するcode-to-paper照合 | PASS — `gammaOf`, `blockA`, `blockA_apply`, `pair_term`, `blockA_decomp`, `paperFT_fk`, `GzGp.phiHat_conj`, `Gz_eq_W`, `Wsummand` をファイルパス込みで確認 |
| JA全文整合監査（内部） | PASS with minor fixes — Failure Ledger 10のLaTeX改行、図表scope、Related Worksのmethod scopeを修正 |
| cold review round 2: transpose bridge self-containedness | PASS — §2.3.4にSchwarz symmetryを用いた本文証明を追加 |
| cold review round 2: aggregate scope | PASS — §2.3.1でspectral interactionを明示しfull `blockA`への非移行を強化 |
| cold review round 2: real-symmetry parity scope | PASS — §5.4に依存性を明示 |
| cold review round 2: \(x_0=0,h'=0\) clarification | PASS — §6にexact exampleと \(-m/18\) coefficientを追加 |
| cold review round 2: Bombieri positioning | PASS — off-line/negative-inertia対応を既知背景として明記 |
| EN同期 + JA↔EN差分監査 | PREVIOUS PASS — V1.0 patch後に再監査 |

## A.3 V1.0 Frozen前に残る公開前ゲート

1. V1.0 JA↔EN最終差分監査とpatch追加コード引用のcode-to-paper照合。
2. 図1〜4の実図制作・LaTeX挿入とcaption確認。
3. LaTeX組版後の数式・参照・改ページ監査。
4. Frozen候補の最終SHA-256固定とpackage manifest作成。

---

**End of Version 1.0 — Publication Candidate Working Draft (Japanese)**
