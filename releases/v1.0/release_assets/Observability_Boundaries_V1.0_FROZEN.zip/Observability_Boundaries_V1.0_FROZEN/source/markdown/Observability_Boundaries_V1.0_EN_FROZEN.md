# Observability Boundaries for Near-Critical Weil Blocks

## — A Finite-Dimensional Analysis of Off-Line Zero Collisions —

**Version 1.0 — Publication Candidate Working Draft (English / Synchronized)**

**Yasuyuki Wakita (Mechanic-Y)**  
**Independent Researcher**

**September 2026**

---

## Abstract

This paper analyzes the local collision limit of a single off-line reflection pair appearing in a finite-dimensional zero-side matrix of Weil type as the pair approaches the critical line. We write the zero-side pair contribution in the current Alpöge–Furman / Anthropic formalization,

\[
m\left(u u^T+\bar u\,\bar u^T\right)=2m\left(xx^T-yy^T\right),
\]

in terms of the local parameter

\[
u_\delta=h(t-i\delta),
\]

and study the relation among matrix collision, negative directions, and detector regularity as \(\delta\to0\).

First,

\[
W_\delta-W_0=O(\delta^2).
\]

Hence, for every finite-dimensional matrix observable \(F\) continuous at \(W_0\), one has \(F(W_\delta)\to F(W_0)\), so no depth-independent positive output separation persists near the collision. This is a collision-limit statement as \(\delta\to0\); it does not preclude a positive separation on a set of off-line depths bounded away from zero. If \(F\) is locally Lipschitz, its output difference is also \(O(\delta^2)\).

On the other hand, under the generic nondegeneracy conditions

\[
x_0\neq0,\qquad P_\perp h'(t)\neq0,
\]

there is an exactly present negative direction for all sufficiently small nonzero \(\delta\), with

\[
\lambda_-(\delta)
=-2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4).
\]

Thus a negative-presence detector distinguishes the collision point exactly, while the geometric robustness margin supporting that decision collapses to zero at order \(O(\delta^2)\).

For the higher-order degenerate branch with \(x_0\neq0\), if the transverse component

\[
r(\delta)=P_{x_\delta^\perp}y_\delta
\]

has first nonzero term

\[
r(\delta)=\delta^{2q+1}w+O(\delta^{2q+3}),
\]

then

\[
\lambda_-(\delta)
=-2m\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4}).
\]

Therefore the possible leading orders are

\[
2,6,10,14,\ldots,
\]

and this sequence is sharp within the real-symmetric analytic model class.

The results are limited to a fixed finite-dimensional, fixed-collision-ordinate, single-pair local analysis. They do not prove RH, establish a no-go theorem for the Alpöge–Furman method as a whole, treat interacting multi-pair systems, or imply conclusions about infinite-dimensional limits.

# 1. Background, Objectives, and Scope of Claims

## 1.1 Background

The quadratic form associated with Weil's explicit formula connects information on the zero side with information on the prime side. In a finite-dimensional zero-side matrix, zeros on the critical line and off-line zeros paired by the functional equation can appear as blocks with different sign structures.

Alpöge and Furman's 2026 paper *More than two thirds of the zeta zeros are simple and on the critical line* combines the rank and positive index of a finite-dimensional zero-side matrix with trace quantities evaluated from the prime side. Its argument does not uniformly bound the depth of each off-line pair from below; rather, it uses the sign count and rank of a finite-dimensional quadratic form exactly.

This paper extracts one symmetric pair block from that zero-side structure and gives a local description of how the matrix, its eigenvalues, and continuous observables degenerate when

\[
\rho_\pm=\frac12\pm\delta+i\gamma
\]

collide on the critical line as $\delta\to0$.

## 1.2 Objectives

The purpose of this paper is not to propose a new global Weil theory. Rather, it is to extract explicitly a single reflection-pair contribution from the current zero-side construction and to distinguish and classify the following features in its collision limit.

1. The local collision rate of the matrix state itself.
2. The loss of output separation within a continuous detector class.
3. Exact detection by a discontinuous negative-presence detector.
4. The collapse of the geometric robustness margin supporting that exact detection.
5. Higher-order transverse degeneration when the generic quadratic branch disappears.
6. Explicit delimitation of scope, failed routes, and unresolved regimes, without extending the results into broader global claims.

The analysis uses finite-dimensional Taylor expansion, rank-two matrix algebra, and continuity. The claims of this paper are limited to the local combination and classification of these features for the specific zero-side pair structure considered here.

## 1.3 Claims Not Made in This Paper

This paper does not claim any of the following.

- A proof of RH, progress toward RH, or a new implication concerning its truth or falsity.
- An absolute no-go theorem for the Alpöge–Furman / Anthropic formalization as a whole.
- That PairCeiling, or the numerical value approximately $0.682$, applies to every method.
- A generalization to all higher traces, nonlinear observables, discontinuous observables, infinite-dimensional limits, or constructions involving arithmetic input.
- Historical priority, a world-first claim, or the nonexistence of prior work.

The literature statement in this paper is limited to the following: within the scope of the search performed, we did not confirm the same local asymptotic formula; this does not assert the complete absence of prior work.

---

# 2. Finite-Dimensional Zero-Side Block Setup

## 2.1 Zero Pair and Complex Ordinate

Let a pair of zeros in the upper half-plane, symmetric with respect to the critical line, be

\[
\rho_+(\delta)=\frac12+\delta+i\gamma,
\qquad
\rho_-(\delta)=\frac12-\delta+i\gamma
=1-\overline{\rho_+(\delta)}.
\tag{2.1}
\]

Here $\gamma\in\mathbb R$ and $\delta\in\mathbb R$, and for the local analysis we set

\[
t:=\gamma.
\]

For a zero $\rho=\beta+i\gamma$, define its complex ordinate by

\[
z_\rho
:=\frac{\rho-\frac12}{i}
=\gamma-i\left(\beta-\frac12\right).
\tag{2.2}
\]

Therefore,

\[
z_{\rho_+(\delta)}=t-i\delta,
\qquad
z_{\rho_-(\delta)}=t+i\delta.
\tag{2.3}
\]

> **Figure 1 insertion point: critical-line collision geometry**  
> In the complex $s$-plane, draw $\rho_\pm=\frac12\pm\delta+i\gamma$ and the critical line $\Re s=\frac12$, showing their collision at the common point $\frac12+i\gamma$ as $\delta\to0$. The figure depicts the upper-half-plane pair induced by the functional equation; the full quartet is not required.

The reflection pair used here is the orbit of \(\sigma(\rho):=1-\bar\rho\):
\[
\{\rho,\sigma(\rho)\}=\{\beta+i\gamma,\;1-\beta+i\gamma\}.
\]
This involution preserves the ordinate \(\gamma\) and is exactly the off-line pairing used in the current zero-side block decomposition.

It is not a procedure that collapses the full conjugation quartet
\[
\{\beta\pm i\gamma,\;1-\beta\pm i\gamma\}
\]
into one block. The lower-half-plane conjugate zeros belong to a different symmetry orbit and are not needed for the single-pair identity `pair_term` analyzed here.

## 2.2 Evaluation Family

Let $U\subset\mathbb C$ be an open neighborhood of $t\in\mathbb R$, reduced if necessary to a neighborhood symmetric under complex conjugation. Let the finite-dimensional evaluation family be

\[
h:U\longrightarrow\mathbb C^d,
\tag{2.4}
\]

and assume that $h$ is holomorphic. In the real-symmetric case, assume

\[
h(\overline z)=\overline{h(z)}.
\tag{2.5}
\]

In particular, $h(t)\in\mathbb R^d$, and every derivative $h^{(k)}(t)$ is a real vector.

For sufficiently small real $\delta$, write

\[
u_\delta
:=h(t-i\delta)
=x_\delta+i y_\delta,
\qquad
x_\delta,y_\delta\in\mathbb R^d.
\tag{2.6}
\]

Equation (2.5) implies

\[
h(t+i\delta)=\overline{u_\delta},
\qquad
x_{-\delta}=x_\delta,
\qquad
y_{-\delta}=-y_\delta.
\tag{2.7}
\]

## 2.3 Derivation of the Single-Pair Block from the Current Zero-Side Construction

The single-pair block used in this paper is not an arbitrarily introduced rank-two toy model. This section extracts equation (2.8) from the zero-side matrix in the current Anthropic Lean implementation corresponding to Alpöge–Furman 2026.

For Version 1.0, the reference implementation is the `zeta23/` project in

\[
\texttt{anthropics/formal-math},
\]

with the audit snapshot fixed at

\[
\boxed{\texttt{fbdc36bbf17d20af3fd0447c6d1a8a02773c9844}}.
\]

The historical standalone repository `anthropics/zeta-23-lean` also exists, but the source binding for Version 1.0 is fixed to the snapshot above.

### 2.3.1 Complex Ordinate and Reflection

In `Zeta23/Defs.lean`,

\[
\gamma_\rho=\frac{\rho-\frac12}{i}
\]

is defined as `gammaOf`. If \(\rho=\beta+i\gamma\), then

\[
\gamma_\rho=\gamma-i\left(\beta-\frac12\right).
\tag{2.8a}
\]

The reflection is implemented as \(\sigma(\rho)=1-\bar\rho\), and

\[
\gamma_{\sigma(\rho)}=\overline{\gamma_\rho}.
\]

### 2.3.2 Zero-Side Evaluation Vector and Transpose Matrix

In the finite-dimensional zero-side construction of `ZeroSide.lean`, the evaluation vector is

\[
u_\rho=\left(\widehat\phi(\gamma_\rho-\tau_k)\right)_{k<d}\in\mathbb C^d.
\tag{2.8b}
\]

The object `blockA` in the same file is defined by

\[
\boxed{A=\sum_\rho m_\rho u_\rho u_\rho^T}.
\tag{2.8c}
\]

Here \(T\) denotes transpose, not conjugate transpose. Entrywise, `blockA_apply` gives

\[
A_{kl}=\sum_\rho m_\rho\widehat\phi(\gamma_\rho-\tau_k)\widehat\phi(\gamma_\rho-\tau_l).
\tag{2.8d}
\]

### 2.3.3 Reflection-Pair Contribution

The zero configuration is invariant under reflection and satisfies \(m_{\sigma(\rho)}=m_\rho\) and \(u_{\sigma(\rho)}=\overline{u_\rho}\). Hence the contribution of an off-line reflection pair to `blockA` is

\[
W_\rho
=m_\rho\left(u_\rho u_\rho^T+\overline{u_\rho}\,\overline{u_\rho}^{\,T}\right).
\tag{2.8e}
\]

Writing \(u_\rho=x_\rho+i y_\rho\),

\[
\boxed{W_\rho=2m_\rho\left(x_\rho x_\rho^T-y_\rho y_\rho^T\right)}.
\tag{2.8f}
\]

This identity is formally proved as the lemma `pair_term` in `Zeta23/ZeroSide.lean`. The lemma `blockA_decomp` further separates the positive and negative rank-one contributions from off-line pairs.

### 2.3.4 Layer Distinction from the Weil Form and Reduction to the Transpose-Type Entry

The zero-side matrix `blockA` must not be conflated with the Weil sesquilinear form `W(f,g)`. The `blockA` entry is
\[
m_\rho\widehat\phi(\gamma_\rho-\tau_k)\widehat\phi(\gamma_\rho-\tau_l),
\tag{2.8g}
\]
a transpose-type product. By contrast, `Wsummand` in `Defs.lean` contains conjugation:
\[
m_\rho h_{f_k}(\gamma_\rho)\overline{h_{f_l}(\overline{\gamma_\rho})}.
\tag{2.8h}
\]

For the selected test family, `paperFT_fk` gives
\[
h_{f_k}(z)=\widehat\phi(z-\tau_k).
\tag{2.8i}
\]
Because \(\phi\) is real-valued and even, `GzGp.phiHat_conj` in `Zeta23/Hypotheses/GzGp.lean` gives the Schwarz symmetry
\[
\widehat\phi(\bar z)=\overline{\widehat\phi(z)}.
\tag{2.8j}
\]
Reality on the real axis is a consequence of this symmetry.

Since \(\tau_l\in\mathbb R\),
\[
\overline{\gamma_\rho}-\tau_l=\overline{\gamma_\rho-\tau_l},
\]
and therefore
\[
\begin{aligned}
\overline{h_{f_l}(\overline{\gamma_\rho})}
&=\overline{\widehat\phi(\overline{\gamma_\rho}-\tau_l)}\\
&=\overline{\widehat\phi(\overline{\gamma_\rho-\tau_l})}\\
&=\widehat\phi(\gamma_\rho-\tau_l).
\end{aligned}
\tag{2.8k}
\]
Hence the Weil zero-side summand reduces termwise to
\[
\boxed{m_\rho\widehat\phi(\gamma_\rho-\tau_k)\widehat\phi(\gamma_\rho-\tau_l)},
\tag{2.8l}
\]
which is exactly the transpose-type `blockA` entry.

The construction therefore does not use a same-argument Hermitian product \(u_\rho u_\rho^*\). The conjugation acts on \(h_{f_l}(\overline{\gamma_\rho})\) and is converted by Schwarz symmetry back into the transpose-type evaluation. Consequently,
\[
u u^T+\bar u\,\bar u^T=2(xx^T-yy^T)
\]
is not merely a matrix convention; it is the actual pair structure of the Weil zero-side summand for this test family.

At snapshot `fbdc36bb...`, this termwise identity is formally proved in `Zeta23/Hypotheses/GzGp.lean` by the `rw` chain using `paperFT_fk`, `GzGp.phiHat_conj`, and `Gz_eq_W`.

### 2.3.5 Local Collision Family

Accordingly, the family analyzed in this paper,

\[
u_\delta:=h(t-i\delta)=x_\delta+i y_\delta,
\]

with

\[
\boxed{W_\delta
=m\left(u_\delta u_\delta^T+\overline{u_\delta}\,\overline{u_\delta}^{\,T}\right)
=2m\left(x_\delta x_\delta^T-y_\delta y_\delta^T\right)},
\tag{2.8}
\]

is a local parameterization of the single off-line reflection-pair contribution `pair_term` appearing in the current zero-side matrix `blockA`.

> **Figure 2 insertion point: zero-side bridge**  
> Show the chain `gammaOf` \(\to\) evaluation vector \(u_\rho\) \(\to\) `blockA` contribution \(\to\) reflection pair \(\to\) `pair_term` \(2m(xx^T-yy^T)\). Explicitly distinguish the `Wsummand` layer from the `blockA` layer and indicate that `Gz_eq_W` bridges them.

### Remark 2.3.1 (Scope)

This bridge establishes only
\[
\boxed{\text{single reflection-pair contribution}\longleftrightarrow W_\delta}.
\]
No theorem in Sections 3–8 is asserted for the spectrum of the full aggregate `blockA` merely from the pair decomposition.

Algebraically,
\[
A=A_{\rm on}+\sum_jW_j,
\]
but in general
\[
\operatorname{spec}\!\left(\sum_jW_j\right)
\]
is not the union of the spectra of the individual \(W_j\). The issue is therefore not an additional algebraic “cross-term” in the definition, but spectral interaction among pair blocks acting on the same ambient space.

This paper derives no separation, orthogonality, commutativity, or perturbative decoupling condition controlling that interaction. Except for the exact direct-sum case, aggregate spectral analysis lies outside the present scope.

## 2.4 Norms, State Distinction, Detectors, and Robustness Margin

We use the Euclidean norm \(\lVert\cdot\rVert\) for vectors and the operator norm \(\lVert\cdot\rVert_{\mathrm{op}}\) for matrices. All standard matrix norms are equivalent in fixed finite dimension.

For a real symmetric matrix \(A\), write \(n_-(A)\) for the number of negative eigenvalues, counted with multiplicity.

### 2.4.1 Exact State Distinction

We say that the states are exactly distinct if there exists \(\delta_0>0\) such that

\[
0<|\delta|<\delta_0\Longrightarrow W_\delta\neq W_0.
\tag{2.11}
\]

This is a statement only about nonidentity of the states themselves. It does not imply robust detection.

### 2.4.2 Detector Distinction

Let \(D:\operatorname{Sym}_d(\mathbb R)\to Y\) be a detector. For the existence of a negative direction, define

\[
\chi_-(A):=\mathbf 1_{\{\lambda_{\min}(A)<0\}}.
\tag{2.12}
\]

The detector \(\chi_-\) is discontinuous on the PSD boundary. We continue to use the full inertia count \(n_-\) as exact algebraic information, but not as a measure of ambient perturbation robustness.

### 2.4.3 Geometric Robustness Margin

Define

\[
\mu_-(A)
:=\operatorname{dist}_{\mathrm{op}}(A,\operatorname{PSD}_d)
=\max\{0,-\lambda_{\min}(A)\}.
\tag{2.13}
\]

Thus \(\mu_-\) is the minimum operator-norm perturbation required to remove negative presence. As a distance function, it is 1-Lipschitz.

### 2.4.4 Continuous Matrix Observables

For a map \(F:\operatorname{Sym}_d(\mathbb R)\to Y\) into a finite-dimensional normed space, treated as a continuous matrix observable, define

\[
\Delta_F(\delta):=\lVert F(W_\delta)-F(W_0)\rVert_Y.
\tag{2.14}
\]

If there exists \(c>0\) such that \(\Delta_F(\delta)\ge c\) for every sufficiently small nonzero depth, we say that \(F\) has a depth-uniform positive output separation.

This paper explicitly distinguishes

\[
\boxed{\text{state distinction}\ ;\ \text{exact detection by a specified detector}\ ;\ \text{robust/depth-uniform separation}}.
\tag{2.15}
\]

# 3. OB-1: Explicit Quadratic Collision Coefficient

Real symmetry and analyticity imply \(W_{-\delta}=W_\delta\), so the quadratic starting order \(W_\delta-W_0=O(\delta^2)\) is already a direct consequence of even analyticity. The substantive information recorded here is the explicit quadratic coefficient.

## Expansion 3.1 (OB-1: Explicit Local Quadratic Coefficient)

Under the assumptions of Section 2,

\[
W_\delta-W_0
=-m\delta^2\left[h''(t)x_0^T+x_0h''(t)^T+2h'(t)h'(t)^T\right]+O(\delta^4),
\tag{3.1}
\]

and therefore

\[
\boxed{\lVert W_\delta-W_0\rVert_{\mathrm{op}}=O(\delta^2)}.
\tag{3.2}
\]

### Proof

Holomorphicity and real symmetry give

\[
x_\delta=x_0-\frac{\delta^2}{2}h''(t)+O(\delta^4),\qquad
y_\delta=-\delta h'(t)+O(\delta^3).
\]

Substitution into \(W_\delta=2m(x_\delta x_\delta^T-y_\delta y_\delta^T)\) yields (3.1). \(\square\)

### Remark 3.2

The role of OB-1 is to provide the local collision rate \(O(\delta^2)\), not merely convergence. The continuous-output obstruction in the next section does not require this rate; the rate is used to quantify locally Lipschitz observables and spectral margins.

# 4. OB-2: Continuous Separation Obstruction

The following is not a Weil-specific theorem; it is an elementary continuity consequence recorded only to separate the topological statement from the quantitative collision rates established elsewhere.

## Observation 4.1 (OB-2: Uniform-Gap Obstruction for Continuous Output)

Assume \(W_\delta\to W_0\), and let \(F\) be a map into a finite-dimensional normed space \(Y\) that is continuous at \(W_0\). Then

\[
F(W_\delta)\to F(W_0).
\tag{4.1}
\]

Hence, for every sufficiently small \(\delta_0>0\),

\[
\boxed{\inf_{0<|\delta|<\delta_0}\lVert F(W_\delta)-F(W_0)\rVert_Y=0}.
\tag{4.2}
\]

### Proof

This is an immediate consequence of continuity. \(\square\)

### Remark 4.2

This proposition does not require holomorphicity, a quadratic collision rate, rank-two structure, or any Weil-specific structure.

## Corollary 4.3 (Locally Lipschitz Observable)

If \(F\) is additionally locally Lipschitz near \(W_0\), then OB-1 gives

\[
\boxed{\lVert F(W_\delta)-F(W_0)\rVert_Y=O(\delta^2)}.
\tag{4.3}
\]

Thus continuity gives \(o(1)\), whereas local Lipschitz regularity together with OB-1 gives \(O(\delta^2)\).

## Corollary 4.4 (Fixed Trace Moments)

For every fixed integer \(k\ge1\),

\[
\operatorname{tr}(W_\delta^k)=\operatorname{tr}(W_0^k)+O(\delta^2).
\tag{4.4}
\]

This conclusion applies only to a fixed finite collection of moments.

## 4.5 Logical Roles of OB-1 and OB-2

\[
\boxed{\begin{array}{lll}
\text{OB-1}&W_\delta-W_0=O(\delta^2)&\text{local rate},\\
\text{OB-2}&W_\delta\to W_0,\ F\text{ continuous}&\text{no depth-uniform output gap},\\
\text{OB-1 + Lipschitz }F&\Delta_F(\delta)=O(\delta^2)&\text{quantitative output rate}.
\end{array}}
\tag{4.5}
\]

OB-2 is a topological qualitative statement; OB-1 is a quantitative refinement specific to the pair path.

# 5. OB-3: Exact Negative Detection with Vanishing Margin

## 5.1 An Elementary Rank-Two Identity

### Lemma 5.1 (Rank-Two Determinant Identity)

Let \(x,y\in\mathbb R^d\) with \(x\neq0\). Set \(e_1=x/\lVert x\rVert\). If \(P_{x^\perp}y\neq0\), define

\[
e_2=\frac{P_{x^\perp}y}{\lVert P_{x^\perp}y\rVert},\qquad
y=a e_1+b e_2,\qquad
b=\lVert P_{x^\perp}y\rVert>0.
\tag{5.1}
\]

For \(W=2m(xx^T-yy^T)\), its restriction to \(\operatorname{span}\{x,y\}\) is

\[
W\big|_{\operatorname{span}\{x,y\}}
=2m\begin{pmatrix}
\lVert x\rVert^2-a^2 & -ab\\
-ab & -b^2
\end{pmatrix},
\tag{5.2}
\]

and

\[
\boxed{
\det\left(W\big|_{\operatorname{span}\{x,y\}}\right)
=-4m^2\lVert x\rVert^2\lVert P_{x^\perp}y\rVert^2
}.
\tag{5.3}
\]

### Proof

Compute the \(2\times2\) determinant in (5.2). In addition,

\[
\operatorname{span}\{x,y\}^{\perp}\subset\ker W,
\]

so every nonzero eigenvalue lies in this active subspace. \(\square\)

## 5.2 Local Eigenvalue of a Nondegenerate Pair

At the collision point \(x_0=h(t)\), write

\[
P_\perp:=P_{x_0^\perp}.
\tag{5.4}
\]

### Theorem 5.2 (OB-3: Negative Direction and Local Spectral Margin)

In addition to the assumptions of Section 2, assume

\[
\boxed{x_0\neq0,\qquad P_\perp h'(t)\neq0}.
\tag{5.5}
\]

Then there exists \(\delta_0>0\) such that whenever

\[
0<|\delta|<\delta_0,
\tag{5.6}
\]

\(W_\delta\) has exactly one negative eigenvalue. Writing it as \(\lambda_-(\delta)\),

\[
\boxed{
\lambda_-(\delta)
=-2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4)
}.
\tag{5.7}
\]

Consequently,

\[
n_-(W_\delta)=1,\qquad n_-(W_0)=0,
\tag{5.8}
\]

and

\[
\boxed{\chi_-(W_\delta)=1,\qquad \chi_-(W_0)=0.}
\tag{5.9}
\]

Here “generic branch” refers only to the local nondegeneracy condition
\[
x_0\neq0,\qquad P_\perp h'(t)\neq0.
\]
No statistical, measure-theoretic, or arithmetic genericity over the set of zeta zeros is asserted.

### Proof

OB-1 gives

\[
x_\delta=x_0+O(\delta^2),\qquad y_\delta=-\delta h'(t)+O(\delta^3),
\]

hence

\[
P_{x_\delta^\perp}y_\delta=-\delta P_\perp h'(t)+O(\delta^3).
\tag{5.10}
\]

For all sufficiently small nonzero \(\delta\), one has \(x_\delta\neq0\) and \(P_{x_\delta^\perp}y_\delta\neq0\). Lemma 5.1 gives a negative determinant on the active subspace, so there is one positive and one negative eigenvalue there. If \(\lambda_+(\delta)\) denotes the positive eigenvalue, then

\[
\lambda_+(\delta)=2m\lVert x_0\rVert^2+O(\delta^2).
\]

Estimating \(\lambda_+\lambda_-\) using Lemma 5.1 and (5.10), and dividing by \(\lambda_+\), yields (5.7). \(\square\)

## 5.3 Exact Negative Detection and Vanishing Geometric Margin

Theorem 5.2 shows that negative presence is exactly detectable at every fixed sufficiently small nonzero depth. A binary output difference, however, does not imply a depth-independent geometric robustness.

By Definition (2.13),

\[
\mu_-(W_\delta)
=\operatorname{dist}_{\mathrm{op}}(W_\delta,\operatorname{PSD}_d)
=|\lambda_-(\delta)|,
\]

and therefore

\[
\boxed{
\mu_-(W_\delta)
=2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4)
}.
\tag{5.11}
\]

Thus

\[
\boxed{\mu_-(W_\delta)\to0\qquad(\delta\to0).}
\tag{5.12}
\]

The following three facts must not be conflated:

\[
\boxed{
\begin{array}{ll}
W_\delta\neq W_0 & \text{state-level distinction},\\[1mm]
\chi_-(W_\delta)\neq\chi_-(W_0) & \text{discontinuous exact negative detection},\\[1mm]
\mu_-(W_\delta)\to0 & \text{vanishing geometric robustness margin}.
\end{array}}
\tag{5.13}
\]

For a continuous observable \(F\) from Section 4, one additionally has \(F(W_\delta)\to F(W_0)\).

> **Figure 3 insertion point: exact negative detection with vanishing margin**  
> Use signed depth \(\delta\) on the horizontal axis and the emerging negative eigenvalue \(\lambda_-(\delta)\) on the vertical axis. Under the generic branch
> \[
> x_0\neq0,\qquad P_\perp h'(t)\neq0,
> \]
> show \(\chi_-=1\) for \(\delta\neq0\) and \(\chi_-=0\) at \(\delta=0\), while
> \[
> \mu_-(W_\delta)=|\lambda_-(\delta)|\sim C\delta^2\to0.
> \]
> Mark this explicitly as the generic \(q=0\) branch. The higher-order branches \(\delta^6,\delta^{10},\ldots\) from Section 5.4 are classified separately and are not part of this plotted curve.

## 5.4 Higher-Order Transverse-Jet Classification

Theorem 5.2 treats the generic branch \(P_\perp h'(t)\neq0\). This section classifies the case in which the generic transverse first derivative vanishes while \(x_0\neq0\) remains fixed.

### Definition 5.4 (Transverse Component)

Assume \(x_0\neq0\). For all sufficiently small \(\delta\), \(x_\delta\neq0\), so define

\[
r(\delta):=P_{x_\delta^\perp}y_\delta
=\left(I-\frac{x_\delta x_\delta^T}{\lVert x_\delta\rVert^2}\right)y_\delta.
\tag{5.14}
\]

Because \(x_\delta\) is even analytic and \(y_\delta\) is odd analytic, the projection is even analytic and

\[
\boxed{r(-\delta)=-r(\delta)}.
\tag{5.15}
\]

Thus \(r\) is an odd analytic vector-valued function. This oddness, and therefore the \(4q+2\) parity classification below, depends essentially on the standing real-symmetry assumption (2.5).

### Theorem 5.5 (Higher-Order Transverse-Jet Theorem)

Under the standing holomorphic and real-symmetry assumption
\[
h(\bar z)=\overline{h(z)},
\]
assume further that \(x_0\neq0\).

#### Case I: \(r\not\equiv0\)

By odd analyticity, there exist a unique integer \(q\ge0\) and a nonzero vector \(w\in\mathbb R^d\) such that

\[
\boxed{r(\delta)=\delta^{2q+1}w+O(\delta^{2q+3})}.
\tag{5.16}
\]

Then, for all sufficiently small nonzero \(\delta\), \(W_\delta\) has exactly one negative eigenvalue and

\[
\boxed{
\lambda_-(\delta)
=-2m\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4})
}.
\tag{5.17}
\]

Hence the leading order of the negative spectral margin is

\[
\boxed{4q+2\in\{2,6,10,14,\ldots\}.}
\tag{5.18}
\]

In particular, \(\delta^4,\delta^8,\ldots\) cannot appear as the leading order in this analytic branch with \(x_0\neq0\).

#### Case II: \(r\equiv0\)

If \(r(\delta)\equiv0\), then \(y_\delta\parallel x_\delta\), so there is a real analytic function \(a(\delta)=O(\delta)\) such that

\[
y_\delta=a(\delta)x_\delta.
\]

Therefore

\[
W_\delta=2m(1-a(\delta)^2)x_\delta x_\delta^T\succeq0
\tag{5.19}
\]

for all sufficiently small \(\delta\), and no negative eigenvalue occurs.

### Proof

Since \(r\) is odd analytic, if \(r\not\equiv0\) then its first nonzero Taylor order is an odd integer \(2q+1\). Hence

\[
\lVert r(\delta)\rVert^2
=\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4}).
\tag{5.20}
\]

Lemma 5.1 gives

\[
\det\left(W_\delta\big|_{\operatorname{span}\{x_\delta,y_\delta\}}\right)
=-4m^2\lVert x_\delta\rVert^2\lVert r(\delta)\rVert^2.
\tag{5.21}
\]

OB-1 gives
\[
\lVert W_\delta-W_0\rVert_{\mathrm{op}}=O(\delta^2),
\]
while \(W_0=2mx_0x_0^T\) has largest eigenvalue \(2m\lVert x_0\rVert^2>0\). By Weyl's eigenvalue perturbation bound,
\[
\left|\lambda_{\max}(W_\delta)-2m\lVert x_0\rVert^2\right|
\le \lVert W_\delta-W_0\rVert_{\mathrm{op}}
=O(\delta^2).
\]
For sufficiently small \(\delta\), this eigenvalue is the positive eigenvalue \(\lambda_+(\delta)\) on the active subspace. Hence
\[
\lambda_+(\delta)=2m\lVert x_0\rVert^2+O(\delta^2).
\]
Therefore \(\lambda_-=\det/\lambda_+\) yields (5.17). Case II follows immediately from collinearity and (5.19). \(\square\)

### Corollary 5.6 (Generic Case)

If \(P_\perp h'(t)\neq0\), then

\[
r(\delta)=-\delta P_\perp h'(t)+O(\delta^3),
\]

so \(q=0\), and Theorem 5.5 recovers Theorem 5.2.

### Corollary 5.7 (Vanishing First Transverse Derivative)

If

\[
P_\perp h'(t)=0,
\]

then \(q=0\) cannot occur. Consequently,

\[
\boxed{
\begin{cases}
r\equiv0,&\text{no negative direction},\\[1mm]
r\not\equiv0,&\lambda_-(\delta)=O(\delta^6)\text{ or higher order}.
\end{cases}}
\tag{5.22}
\]

Thus the condition \(P_\perp h'(t)=0\) alone does not imply disappearance of the negative direction.

### Remark 5.7a (Dependence of the Parity Law on Real Symmetry)

Theorem 5.5 is not an order classification for arbitrary analytic matrix families. If the standing assumption \(h(\bar z)=\overline{h(z)}\) is removed, the evenness of \(x_\delta\) and oddness of \(y_\delta\) generally fail, and \(r(\delta)\) need not be odd. Even orders such as \(\operatorname{ord}_0r=2\) may then occur, so behavior such as \(\lambda_-(\delta)\asymp-\delta^4\) cannot be excluded in general.

Thus \(2,6,10,14,\ldots\) is a parity law within the real-symmetric analytic model class.

### Example 5.8 (Sharpness of the Order Sequence)

For every integer \(q\ge0\), the order \(4q+2\) is realizable. Let \(d=2\) and define

\[
h(z)=e_1+e_2(z-t)^{2q+1}.
\tag{5.23}
\]

Then \(x_\delta=e_1\) and \(y_\delta=(-1)^{q+1}\delta^{2q+1}e_2\), so

\[
W_\delta=2m\begin{pmatrix}1&0\\0&-\delta^{4q+2}\end{pmatrix},
\]

and hence

\[
\boxed{\lambda_-(\delta)=-2m\delta^{4q+2}.}
\tag{5.24}
\]

Therefore the sequence \(2,6,10,14,\ldots\) is sharp within the real-symmetric analytic model class. This does not claim that every \(q\) is realized by the actual Weil evaluation family.

### Remark 5.9 (Separation from the \(x_0=0\) Branch)

Theorem 5.5 uses \(x_0\neq0\) essentially. When \(x_0=0\), the positive eigenvalue itself collapses to zero, so that regime is treated separately in the next section.

# 6. The Degenerate Regime $x_0=0$

Theorem 5.2 assumes $x_0\neq0$. When $x_0=0$, there is no positive rank-one direction at the collision point, so the same projection coefficient must not be used. This section treats that case separately.

## Proposition 6.1 (Vanishing-Base-Vector Regime)

In addition to the assumptions of Section 2, assume

\[
\boxed{
x_0=0,
\qquad
h'(t)\neq0
}.
\tag{6.1}
\]

Then

\[
x_\delta=O(\delta^2),
\qquad
y_\delta=-\delta h'(t)+O(\delta^3),
\tag{6.2}
\]

and consequently

\[
\boxed{
W_\delta
=-2m\delta^2h'(t)h'(t)^T
+O(\delta^4)
}.
\tag{6.3}
\]

Furthermore, there exists $\delta_0>0$ such that, for $0<|\delta|<\delta_0$, $W_\delta$ has exactly one negative eigenvalue and

\[
\boxed{
\lambda_-(\delta)
=-2m\lVert h'(t)\rVert^2\delta^2
+O(\delta^4)
}.
\tag{6.4}
\]

### Proof

Substituting $x_0=0$ into the Taylor expansions used in the proof of Expansion 3.1 gives (6.2). Hence $x_\delta x_\delta^T=O(\delta^4)$ and

\[
y_\delta y_\delta^T
=\delta^2h'(t)h'(t)^T+O(\delta^4),
\]

so (2.8) gives (6.3). Moreover,

\[
\delta^{-2}W_\delta
\longrightarrow
-2m h'(t)h'(t)^T.
\]

The matrix on the right has the simple negative eigenvalue $-2m\lVert h'(t)\rVert^2$. Continuity of eigenvalues together with the remainder estimate in (6.3) gives (6.4). Since $W_\delta$ is the difference of a positive rank-one matrix and a positive rank-one matrix, it has at most one negative eigenvalue; the negative eigenvalue just identified therefore makes the count exactly one. $\square$

### Remark 6.2 (Higher-Order Degenerate Regime)

If \(x_0=0\) and \(h'(t)=0\), the leading order depends on \(h''(t)\), \(h'''(t)\), and higher derivatives. This paper does not give a complete classification of that higher-order degenerate regime, and the coefficient in Proposition 6.1 must not be applied formally to it.

A leading PSD term does not by itself exclude a higher-order negative direction. For example, in \(d=2\),
\[
h(z)=e_1(z-t)^2+e_2(z-t)^3
\]
gives
\[
h(t)=0,\qquad h'(t)=0,\qquad h(t-i\delta)=-\delta^2e_1+i\delta^3e_2.
\]
Hence
\[
W_\delta=2m
\begin{pmatrix}
\delta^4&0\\
0&-\delta^6
\end{pmatrix},
\qquad
\boxed{\lambda_-(\delta)=-2m\delta^6.}
\]

More generally, if \(h''(t)\neq0\) and \(P_{h''(t)^\perp}h'''(t)\neq0\), then
\[
\lambda_-(\delta)
=
-\frac{m}{18}
\left\|P_{h''(t)^\perp}h'''(t)\right\|^2
\delta^6+O(\delta^8).
\]
A complete higher-order classification of this branch is left outside the present scope.

---

# 7. OB-4: Finite-Dimensional Regularity Consequence

OB-4 is recorded not as a universal unobservability principle, but as a general continuity consequence for finite-dimensional continuous constructions.

## Proposition 7.1 (OB-4: Finite-Dimensional Regularity Consequence)

Let \(E_\delta\) be finite-dimensional evaluation data and assume

\[
E_\delta\to E_0\qquad(\delta\to0).
\]

Suppose that the finite-dimensional matrix family is given by a construction map \(\mathcal W\), continuous near \(E_0\), via

\[
W_\delta=\mathcal W(E_\delta).
\]

Then \(W_\delta\to W_0\). Consequently, for every finite-dimensional matrix observable \(F\) continuous at \(W_0\),

\[
F(W_\delta)\to F(W_0),
\]

and no depth-independent positive output separation exists near the collision.

### Proof

This is an immediate consequence of preservation of limits under composition of continuous maps. \(\square\)

### Remark 7.2 (Weil Setting)

For the pair block in this paper,

\[
E_\delta=(h(t-i\delta),h(t+i\delta)).
\]

Holomorphicity is a sufficient condition for \(E_\delta\to E_0\), and equation (2.8) is polynomial in the evaluation data and therefore continuous.

### Remark 7.3 (Scope)

OB-4 does not rule out detectors discontinuous at \(W_0\), parameter-dependent detectors, changing dimension, infinite-dimensional operator limits, additional arithmetic input, interacting multi-pair systems, or other constructions outside the finite-dimensional continuous setup. It must therefore not be used as an absolute no-go theorem for all Weil methods, the Alpöge–Furman / Anthropic method as a whole, all nonlinear observables, or all arithmetic observables.

## Table 1: Roles of OB-1 through OB-4

| Result | Main assumptions | Conclusion | Role |
|---|---|---|---|
| OB-1 | fixed finite \(d\); holomorphic real-symmetric \(h\); single-pair block | \(W_\delta-W_0=O(\delta^2)\) | local collision rate |
| OB-2 | \(W_\delta\to W_0\); \(F\) continuous | no depth-uniform positive output gap | topological separation obstruction |
| Quantitative OB-2 corollary | OB-1 + locally Lipschitz \(F\) | output difference \(O(\delta^2)\) | quantitative rate |
| OB-3 | \(x_0\neq0\); \(P_\perp h'(t)\neq0\) | exact negative detection; \(\mu_-\sim C\delta^2\) | generic detector / margin separation |
| OB-3 higher-order extension | \(x_0\neq0\); \(r(\delta)\not\equiv0\); \(\operatorname{ord}_0r=2q+1\) | \(\lambda_-\sim-2m\lVert w\rVert^2\delta^{4q+2}\) | transverse-jet classification |
| OB-4 | finite-dimensional continuous construction | disappearance of the gap for continuous observables | general continuity consequence |

# 8. Three Information-Loss / Detection Regimes

Zero-side information is not handled in a single way. This paper distinguishes at least the following three regimes.

## Table 2: Erasure / Compression Loss / Vanishing-Margin Detection

| Type | State of information | Typical map | Meaning in this paper |
|---|---|---|---|
| Type I — Erasure | depth information itself disappears before or during encoding | \((\delta,\gamma)\mapsto\gamma\) | \(\delta\) cannot be recovered downstream from that ordinate-only representation |
| Type II — Compression Loss | geometry remains in the full matrix but is discarded at a coarse certificate interface | aggregate matrix \(\to\) inertia/rank/trace interface | geometry not used by the certificate may be lost |
| Type III — Vanishing-Margin Detection | a discontinuous detector gives exact detection, but the distance to its decision boundary collapses to zero | \(W_\delta\mapsto(\chi_-(W_\delta),\mu_-(W_\delta))\) | in the generic branch \(\mu_-\asymp\delta^2\); in a higher-order transverse branch \(\mu_-\asymp\delta^{4q+2}\); exact detection and vanishing margin remain distinct |

Type II does not assert that information is absent from the full matrix, nor does it mean that a coarse certificate is mathematically invalid.

In the generic \(q=0\) branch of Type III,

\[
\chi_-(W_\delta)=1\qquad(0<|\delta|<\delta_0),
\]

while

\[
\mu_-(W_\delta)
=2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4)\to0.
\tag{8.1}
\]

In the higher-order transverse branch of Section 5.4, the same exact detection may persist while

\[
\mu_-(W_\delta)
=2m\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4}),
\]

so that the margin disappears at a higher order.

Accordingly, the central distinction in this version is not the earlier binary formulation but the three-layer structure

\[
\boxed{
\text{state distinction}\ ;\
\text{discontinuous exact detection}\ ;\
\text{vanishing geometric margin / continuous no-gap}
}.
\tag{8.2}
\]

It is also important that

\[
\text{no depth-uniform continuous separation}
\neq
\text{nonexistence of off-line structure}.
\tag{8.3}
\]

> **Figure 4 insertion point: information-flow classification**  
> Separate the single-pair layer, aggregate/certificate layer, and continuous-observable layer. Show the negative-presence detector \(\chi_-\) and the geometric margin \(\mu_-\) as distinct nodes.

# 9. Multiple Pairs: Exact Direct-Sum Case

The only multi-pair case formalized in this section is the noninteracting exact direct sum. No direct-sum or approximate-orthogonality conclusion is drawn solely from a qualitative statement that the \(\gamma_j\) are separated.

## Theorem 9.1 (Finite Exact Direct-Sum Extension)

For each \(j\) in a finite set \(J\), suppose that a finite-dimensional block \(W_{\delta_j}^{(j)}\) satisfies the assumptions of Section 2 and Theorem 5.2; namely,

\[
x_0^{(j)}\neq0,
\qquad
P_{\perp,j}h_j'(t_j)\neq0,
\qquad
m_j>0.
\tag{9.1}
\]

Define the exact direct-sum matrix by

\[
\boxed{
W(\boldsymbol\delta)
:=\bigoplus_{j\in J}W_{\delta_j}^{(j)}
}.
\tag{9.2}
\]

Then, for every \(j\), there exists \(\delta_{0,j}>0\) such that, if

\[
0<|\delta_j|<\delta_{0,j},
\]

the corresponding block has exactly one negative eigenvalue and

\[
\boxed{
\lambda_{-,j}(\delta_j)
=-C_j\delta_j^2+O(\delta_j^4)
},
\tag{9.3}
\]

where

\[
\boxed{
C_j
:=2m_j\lVert P_{\perp,j}h_j'(t_j)\rVert^2
>0
}.
\tag{9.4}
\]

Furthermore, because the spectrum of a direct sum is the multiset union of the spectra of its blocks, for sufficiently small \(\boldsymbol\delta\),

\[
n_-\bigl(W(\boldsymbol\delta)\bigr)
=\#\{j\in J:\delta_j\neq0\}.
\tag{9.5}
\]

Each nonzero \(\delta_j\) is understood to lie in its corresponding local neighborhood.

### Proof

Equations (9.3) and (9.4) follow by applying Theorem 5.2 blockwise. The eigenvalues of a direct sum form the multiset union of the block spectra, and inertia is additive, yielding (9.5). \(\square\)

### Corollary 9.2 (Direct-Sum Negative Spectral Margin)

Assume at least one \(\delta_j\neq0\). Define

\[
\mu(\boldsymbol\delta)
:=\min_{j:\delta_j\neq0}|\lambda_{-,j}(\delta_j)|.
\tag{9.6}
\]

For finitely many fixed blocks, as \(\max_j|\delta_j|\to0\),

\[
\mu(\boldsymbol\delta)
\asymp
\min_{j:\delta_j\neq0}C_j\delta_j^2.
\tag{9.7}
\]

Thus the weakest negative spectral margin of the full direct sum is controlled by the shallowest nondegenerate block.

### Remark 9.3 (Future Work)

In an actual aggregate matrix, different pair contributions may act in the same ambient space and may contain cross terms or dependencies among evaluation vectors. This paper proves no quantitative separation condition for sufficiently separated pairs, approximately orthogonal pairs, or nearby/interacting pairs. These cases are excluded from the direct-sum theorem and left to future work; the concrete research program is organized as Track B in Section 12.7.

# 10. Relation to Prior Work

## 10.1 Weil's Quadratic Form and the Alpöge–Furman / Anthropic Formalization

Weil's explicit formula relates positivity of a quadratic form on an appropriate test-function class to RH [3]. The matrix \(W_\delta\) considered here is not a replacement for that full construction; it is a local parameterization of a single reflection-pair contribution extracted from `blockA` / `pair_term` in the current formalization.

Alpöge–Furman 2026 [1] separates a finite-dimensional zero-side matrix into positive contributions from critical-line zeros and contributions from off-line pairs, and uses rank, positive index, trace, and Frobenius norm. Anthropic's current Lean 4 formalization [2] records the main theorem and its linear-algebraic and analytic inputs in a machine-checkable form.

The index/rank argument in the source paper is designed not to require exact use of the off-line depth, including cases where the evaluation vectors of a near-critical pair become nearly dependent. The results here do not invalidate that exact argument. Rather, they establish a different local property of the same single-pair data: the continuous output separation and the geometric margin supporting negative-presence detection both collapse at the collision.

## 10.2 Bombieri's Finite Truncations

Bombieri [4] studied finite truncations and eigenvalues of Weil's quadratic functional. Under the assumption that RH fails through only finitely many off-line zeros, he showed that, for sufficiently large truncations, the number of negative eigenvalues equals half the number of zeros violating RH.

Thus the global correspondence between off-line zeros and negative inertia is known background; this paper does not claim its discovery. Bombieri's result concerns a global count for sufficiently large finite truncations, whereas this paper locally describes, for one reflection-pair contribution extracted from the current zero-side construction, the explicit eigenvalue coefficient, collapse of the geometric margin, and real-symmetric higher-order transverse-jet classification in the collision limit \(\delta\to0\). They are not the same theorem. No claim of historical priority is made for the \(4q+2\) classification in Theorem 5.5.

If a finite set of off-line exceptions all have nonzero depth, then

\[
\delta_{\min}
:=\min_\rho\left|\Re\rho-\frac12\right|>0.
\]

This is not a separate explicit assumption attributed to Bombieri; it follows from the elementary fact that a finite set of nonzero real numbers has a positive minimum absolute value.

## 10.3 Higher-Level Correlations

Rudnick–Sarnak [5] and the higher-level-correlation framework combined with semidefinite programming by Gonçalves–de Laat–Leijenhorst [6] yield strong information on zero multiplicity. The relevant framework used in [6], however, assumes GRH.

Therefore, along the direct route inspected here, ordinary \(R_3\) or higher-level correlation results cannot simply be inserted as unconditional horizontal detectors. This is a limited statement about the input route audited here, not a rejection of higher-level-correlation research in general.

Lamzouri [9] gave a separate, more direct unconditional proof in September 2026 of the same approximately 67.25% proportion of zeros that are simple and on the critical line. His proof replaces the finite-dimensional matrix framework of Alpöge–Furman by a Hilbert-space inequality and directly applies a Montgomery-type pair-correlation input. This paper does not analyze that separate mechanism; it locally analyzes the finite-dimensional zero-side pair structure appearing in the Alpöge–Furman / Anthropic formalization. Consequently, no claim is made that the local observability analysis developed here transfers automatically to Lamzouri's proof.

## 10.4 Broad Background from de Branges and Krein

de Branges spaces [7], Krein-type indefinite structures, and extension problems for positive-definite functions [8] provide a broad theoretical background for relations among entire functions, spectral theory, positivity, and indefiniteness.

The results OB-1 through OB-4 are not proved by invoking a specific theorem from these theories. This paper therefore does not attribute an unverified prior theorem to de Branges or Krein; they are cited only as broad background.

## 10.5 Limited Novelty Statement

Within the literature search performed, we did not confirm a local formulation identical to equation (5.7) or to the higher-order classification of Theorem 5.5, especially equation (5.17). This does not establish the complete absence of prior work, and no historical-priority claim is made.

# 11. Failure Ledger

The Failure Ledger preserves routes examined during the investigation together with their present status and scope. A status of “CLOSED” or “REJECTED” applies only to the audited class or proposed form stated in the table; it does not automatically extend to all adjacent methods.

## Table 3: Failure Ledger

| Route | Status | Present assessment and scope limitation |
|---|---|---|
| support (>1) extension | PARKED | It requires stronger Hardy–Littlewood-type prime-correlation input beyond the present prime-side diagonal evaluation. No impossibility-in-principle claim is made. |
| scalar bandwidth-one linear certificate improvements | CLOSED within audited class | PairCeiling applies only to the audited scalar linear certificate class. Bounds including the approximately 0.6818287 value in the accompanying Lean material [2] come with the stated stability correction and enclosure hypothesis. Approximately 0.682 is not used as a ceiling for all methods. |
| finite same-block higher trace moments as a uniform detector | CLOSED for this role | Each fixed-degree trace moment is polynomial and locally Lipschitz, so OB-1 together with Corollaries 4.3–4.4 gives a difference of \(O(\delta^2)\). OB-2 alone already implies that no uniform positive gap exists. This does not mean that higher traces or nonlinear observables are invalid in general. |
| ordinary \(R_3\) as unconditional RH-free input | CLOSED for the inspected route | The Rudnick–Sarnak / Gonçalves–de Laat–Leijenhorst framework inspected here is conditional on GRH. This is not a no-go result for higher-level correlations in general. |
| simple continuous 3-cycle detector | CLOSED in audited form | As long as the audited form is constructed as a continuous function of finite-dimensional evaluation data, it obeys the same collision no-gap result. Constructions involving discontinuity, limit dependence, or separate inputs are outside this entry. |
| same-zero Gram \(B=\sum uu^*\) from the ordinary one-variable Weil formula | WITHDRAWN as proposed | The ordinary one-variable Weil formula does not justify an unconditional identification with the proposed same-zero positive Gram. The former identification is not used. |
| nonvanishing finite-magnitude spectral gap at collision | REJECTED | A negative eigenvalue may exist, but it vanishes continuously as \(\lambda_-(\delta)\to0\). The inertia count jumps; there is no finite-magnitude eigenvalue gap. |
| Hermitian/real-symmetric encoding immediately erases \(\delta\) | WITHDRAWN | In the single-pair ZeroSide, \(\delta\) may remain through \(y_\delta\) and the negative signature. Any information loss must instead be distinguished as a later compression/interface loss or a zero-margin phenomenon. |
| horizontal energy uniformly counts off-line zeros | REJECTED without depth lower bound | The depth-sensitive energy of one pair is typically \(O(\delta^2)\); allowing \(\delta\to0\) removes any uniform positive lower bound per pair. Without a depth lower bound, it cannot uniformly control the off-line count. |
| first-order transverse degeneracy interpreted as complete sign loss | WITHDRAWN | An earlier interpretation incorrectly inferred disappearance of the negative direction from \(P_\perp h'(t)=0\). Recalculation triggered by an external cold review showed, from odd analyticity of \(r(\delta)=P_{x_\delta^\perp}y_\delta\), that \(\lambda_-\sim-2m\lVert w\rVert^2\delta^{4q+2}\). The negative branch disappears only in the completely collinear case \(r\equiv0\). |

### Methodological Note

If rejected hypotheses are simply deleted, the same misidentification may reappear in a different form. This paper therefore preserves broken hypotheses together with their scopes and reasons for failure. The Failure Ledger itself must not be used as a no-go list for constructions not enumerated here.

# 12. Limitations, Uniformity Scope, and Open Problems

## 12.1 Fixed Finite Dimension and Fixed Collision Ordinate

The asymptotic results in this paper are local statements for fixed finite dimension \(d\), fixed collision ordinate \(t\), and a fixed holomorphic evaluation family \(h\).

No uniform asymptotic or interchange of limits is claimed for a joint limit in which

\[
d\to\infty,\qquad |t|\to\infty,\qquad x_0\to0
\]

is taken simultaneously with \(\delta\to0\).

## 12.2 Scope as \(x_0\to0\)

The \(x_0\neq0\) branches of Theorems 5.2 and 5.5 use

\[
\lambda_+(\delta)=2m\lVert x_0\rVert^2+O(\delta^2).
\]

Accordingly, no claim is made that the remainder constants or the admissible local radius \(\delta_0\) are uniform as \(x_0\to0\). The \(x_0=0\) branch is treated independently in Section 6.

## 12.3 Scope as \(t\to\infty\)

Taylor remainders, \(h^{(k)}(t)\), \(P_\perp h'(t)\), and local radii may all depend on \(t\). This paper neither assumes nor derives a global transverse nondegeneracy condition such as

\[
\inf_{|t|\ge T}\lVert P_\perp h'(t)\rVert>0.
\]

## 12.4 Dimension Scope

If \(d=1\) and \(x_0\neq0\), then \(P_\perp=0\), so the generic transverse branch of Theorem 5.2 cannot occur. Thus that branch effectively requires \(d\ge2\). This does not mean that the entire paper assumes \(d\ge2\); the vanishing-base-vector regime of Section 6 is a separate case.

## 12.5 Numerical Robustness

This paper identifies asymptotic orders for the geometric spectral margin but does not quantify floating-point error, a noise model, condition numbers, or finite-precision detection thresholds.

## 12.6 Arithmetic Scope

This paper provides no new prime-side estimate and neither assumes nor proves the existence of off-line zeros. Consequently, it yields no improvement in a critical-line proportion, no new zero-count bound, and no implication for RH.

## 12.7 Next Research Agenda

The next stage beyond the theorems of V1.0 is organized in the following order. These are **open research problems**, not additional theorems or empirical claims of V1.0.

### Track A — Non-Vacuity of Jet Strata in the Actual Taper Family

The actual evaluation family in the current zero-side construction has the constrained form

\[
h_{P,T}(z)
=
\left(
\widehat\phi(z-\tau_k)
\right)_{k<d},
\qquad
\tau_k=T+k\frac{2\pi}{L},
\]

so all components are translates of the same \(\widehat\phi\). This family satisfies the holomorphic and real-symmetric hypotheses of Theorem 5.5. Therefore **the classification theorem itself applies to the actual family**.

What remains open is whether the higher-order strata of Theorem 5.5 are nonempty within this constrained family, in particular whether

\[
q\ge1
\]

can actually occur.

Under \(x_0=h(t)\neq0\), the first transverse degeneracy

\[
P_{h(t)^\perp}h'(t)=0
\]

is equivalent to

\[
h'(t)=\alpha h(t),
\]

which componentwise requires the simultaneous jet condition

\[
\widehat\phi'(t-\tau_k)
=
\alpha\,\widehat\phi(t-\tau_k)
\qquad(k<d).
\]

The next problem is to characterize this condition, and the vanishing of higher transverse jets, under the structural constraints imposed by the compactly supported taper and the equally spaced grid \(\tau_k\).

Concrete questions are:

- characterize when the generic \(q=0\) branch occurs in the actual taper family;
- determine whether higher-order branches \(q\ge1\) are realizable, or prove an obstruction if they are not;
- classify the \(x_0=0,\ h'(t)=0\) regime under the same actual-family constraints;
- retain the convention that “generic” means only local jet nondegeneracy, not statistical genericity over actual zeta zeros;
- make no assumption or claim that off-line zeros exist: this is a non-vacuity problem for conditional local geometry.

### Track B — Spectral Interaction from a Single Pair to the Aggregate Matrix

Next, consider

\[
A_\delta
=
A_{\mathrm{on}}
+
\sum_j W_j(\delta_j).
\]

The problem is to identify conditions under which a single-pair negative branch survives in the presence of other pair contributions and background acting on the same ambient space.

Main questions include:

- error bounds deriving an approximate direct sum from subspace angles, approximate orthogonality, or quantitative separation;
- for
  \[
  A_\delta=B+W_\delta,
  \]
  spectral-gap, subspace-angle, or perturbative conditions that preserve the negative branch;
- quantitative eigenvalue splitting and margin degradation for nearby or interacting pairs;
- quantitative information loss between the local pair asymptotic and an aggregate certificate interface;
- identification of minimal additional assumptions needed to pass from the exact direct-sum result of Section 9 to a general aggregate matrix.

### Track C — Changing Dimension, Large Ordinate, and Operator Limits

Investigate whether the fixed-\(d,t,h\) local classification extends to joint regimes such as

\[
d=d(\delta)\to\infty,\qquad
|t|\to\infty,\qquad
\delta\to0.
\]

Main questions include:

- uniform control of Taylor remainders and transverse jets in \(d\) and \(t\);
- noncommutativity of the limits \(\delta\to0\) and \(d\to\infty\) or \(t\to\infty\);
- operator topologies under which finite-dimensional eigenvalue branches persist;
- conditions under which the \(4q+2\) scaling survives a changing-dimension limit, or transitions to a different scaling law.

### Track D — Prior Art, Numerical Robustness, and Detector Realization

In parallel with Tracks A–C:

- perform a targeted prior-art search for local jet classifications equivalent to Theorem 5.5 in analytic matrix perturbation, transversality, jet geometry, singularity theory, control theory, and related areas;
- introduce a noise model, finite precision, and condition numbers to quantify the relation between
  \[
  \mu_-(W_\delta)
  \]
  and an operational detection threshold;
- distinguish a constant output gap of a discontinuous exact detector from a vanishing geometric margin in an explicit numerical decision problem.

### Priority

Track A is the immediate next target. Theorem 5.5 applies to the actual taper family, but the **realizability or impossibility** of higher-order branches \(q\ge1\) within that family is currently open, and this question most directly determines the non-vacuity of the higher-order local classification.

Track B should follow Track A and test how much of the single-pair geometry survives in the aggregate spectrum. Track C then addresses finite-to-infinite observability. Track D proceeds in parallel.

None of these problems is included in the theorems of V1.0. V1.0 supplies the fixed finite-dimensional single-pair classification from which they begin.

# 13. Conclusion: A Local Detector-Regularity Boundary

The local picture established here is not a binary division into “observable” and “unobservable.”

In the nondegenerate branch of Theorem 5.2, for every sufficiently small nonzero depth one has \(W_\delta\neq W_0\), and the negative-presence detector distinguishes the states exactly:

\[
\chi_-(W_\delta)=1,\qquad \chi_-(W_0)=0.
\]

However, the geometric margin supporting that decision satisfies

\[
\mu_-(W_\delta)\to0,
\]

and in the generic branch,

\[
\mu_-(W_\delta)
=2m\lVert P_\perp h'(t)\rVert^2\delta^2+O(\delta^4).
\]

For every continuous finite-dimensional observable, meanwhile,

\[
F(W_\delta)\to F(W_0),
\]

so there is no depth-uniform positive output separation.

Moreover, disappearance of the generic transverse derivative does not force disappearance of the negative direction. If a higher transverse jet is present, a higher-order branch occurs:

\[
\lambda_-(\delta)
=-2m\lVert w\rVert^2\delta^{4q+2}+O(\delta^{4q+4}),
\]

with possible leading orders \(2,6,10,14,\ldots\). This sequence is sharp within the real-symmetric analytic model class.

Thus the appropriate local conclusion is

\[
\boxed{\text{exact negative detection can persist while its geometric margin collapses}}.
\]

The word “boundary” here refers to a boundary among detector regularity classes within a fixed finite-dimensional single-pair local family. It is not extended into a no-go theorem for all Weil constructions, a statement of general unobservability of arithmetic information, an interacting multi-pair result, or a conclusion about infinite-dimensional limits. As organized in Section 12.7, the next step is to test the non-vacuity of the jet strata in the actual taper family, followed by aggregate spectral interaction and then finite-to-infinite limits.

# References

[1] L. Alpöge and N. Furman, *More than two thirds of the zeta zeros are simple and on the critical line*, arXiv:2608.13637, 2026.

[2] Anthropic, `formal-math` repository, `zeta23/` formalization project, audit snapshot `fbdc36bbf17d20af3fd0447c6d1a8a02773c9844`, 2026. Historical standalone companion: `anthropics/zeta-23-lean`.

[3] A. Weil, “Sur les ‘formules explicites’ de la théorie des nombres premiers,” *Meddelanden från Lunds Universitets Matematiska Seminarium*, 1952, 252–265.

[4] E. Bombieri, “Remarks on Weil’s quadratic functional in the theory of prime numbers, I,” *Atti della Accademia Nazionale dei Lincei. Rendiconti Lincei. Matematica e Applicazioni*, Series 9, 11 (2000), no. 3, 183–233.

[5] Z. Rudnick and P. Sarnak, “Zeros of principal \(L\)-functions and random matrix theory,” *Duke Mathematical Journal* 81 (1996), no. 2, 269–322.

[6] F. Gonçalves, D. de Laat, and N. Leijenhorst, “Multiplicity of nontrivial zeros of primitive \(L\)-functions via higher-level correlations,” arXiv:2303.01095v2, 2025.

[7] L. de Branges, *Hilbert Spaces of Entire Functions*, Prentice-Hall, 1968.

[8] M. G. Krein and H. Langer, “Continuation of Hermitian positive definite functions and related questions,” *Integral Equations and Operator Theory* 78 (2014), no. 1, 1–69.

[9] Y. Lamzouri, *A new proof that more than \(2/3\) of the zeros of the Riemann zeta function are simple and on the critical line*, arXiv:2609.02882, 2026.

# Appendix A. Theorem Dependencies and Version Audit

## A.1 Theorem Dependencies

| Result | Main dependencies |
|---|---|
| zero-side bridge | `gammaOf`, `blockA`, `blockA_apply`, `pair_term`, `blockA_decomp`, `paperFT_fk`, `GzGp.phiHat_conj`, `Gz_eq_W` at snapshot `fbdc36bb...` |
| OB-1 | holomorphic real-symmetric evaluation family; single-pair block (2.8); Taylor expansion |
| OB-2 | path convergence \(W_\delta\to W_0\); continuity of \(F\) |
| Lipschitz corollary | \(O(\delta^2)\) from OB-1; local Lipschitz bound |
| fixed trace moments | Lipschitz corollary; fixed finite-degree polynomial map |
| rank-two identity | algebra on the active two-dimensional subspace of \(2m(xx^T-yy^T)\) |
| OB-3 generic branch | OB-1; rank-two identity; \(x_0\neq0\); \(P_\perp h'(t)\neq0\) |
| geometric margin | OB-3; \(\mu_-(A)=\operatorname{dist}_{op}(A,PSD_d)\) |
| higher-order transverse-jet theorem | \(x_0\neq0\); odd analyticity of \(r(\delta)\); rank-two identity |
| vanishing-base-vector proposition | \(x_0=0\); \(h'(t)\neq0\); Taylor expansion |
| OB-4 | finite-dimensional continuous construction |
| direct-sum theorem | generic OB-3 applied blockwise; exact direct-sum spectrum |

## A.2 Version 1.0 Publication-Patch Audit

| Audit item | Result |
|---|---|
| v0.3 Frozen was not modified in place | PASS — branched through the v0.4 Working Draft into the V1.0 Publication Candidate |
| state / detector / geometric margin / continuous observable separated | PASS — Section 2.4 |
| \(n_-\) not used as an ambient robustness measure | PASS — Sections 2.4.2–2.4.3 |
| \(\chi_-\) and \(\mu_-\) separated | PASS — Sections 2.4 and 5.3 |
| OB-2 reduced to a continuity-only statement | PASS — Section 4 |
| OB-1 restricted to a local quantitative rate | PASS — Sections 3 and 4.5 |
| bridge to the current zero-side code established in the text | PASS — Section 2.3 |
| source binding fixed to `formal-math @ fbdc36bb...` | PASS — Section 2.3 |
| transpose `blockA` distinguished from conjugated `Wsummand` | PASS — Section 2.3.4 |
| generic OB-3 explicitly states \(x_0\neq0\) and \(P_\perp h'(t)\neq0\) | PASS — Section 5.2 |
| generic negative margin defined as \(\mu_-\sim C\delta^2\) | PASS — Section 5.3 |
| earlier misconception \(P_\perp h'(t)=0\Rightarrow\) sign loss withdrawn | PASS — Section 5.4 and Failure Ledger |
| higher-order orders \(4q+2=2,6,10,\ldots\) proved | PASS — Theorem 5.5 |
| sharpness example included | PASS — Example 5.8 |
| \(x_0=0\) branch separated as an independent regime | PASS — Section 6 |
| fixed \(d,t,h\) and no joint-limit claim stated | PASS — Section 12 |
| failure of the generic transverse branch for \(d=1\) stated | PASS — Section 12.4 |
| interacting pairs not promoted to a theorem | PASS — Sections 9.3 and 12.7 |
| “observability” restricted to a local detector-class boundary | PASS — Sections 8 and 13 |
| RH, absolute no-go, and priority claims excluded | PASS — Sections 1.3, 7.3, 12, and 13 |
| Related Works updated to current arXiv / repository baseline | PASS — Section 10 and References |
| Figure 1–4 specifications and Tables 1–3 synchronized with V1.0 | PASS — Figure 3, Table 1, and Table 2 reflect the higher-order classification |
| code-to-paper audit against snapshot `fbdc36bb...` | PASS — `gammaOf`, `blockA`, `blockA_apply`, `pair_term`, `blockA_decomp`, `paperFT_fk`, `GzGp.phiHat_conj`, `Gz_eq_W`, and `Wsummand` checked with file paths |
| JA full-text internal consistency audit | PASS with minor fixes — Failure Ledger 10 LaTeX line break, figure/table scope, and Related Works method scope corrected |
| cold review round 2: transpose-bridge self-containedness | PASS — Section 2.3.4 now contains the Schwarz-symmetry reduction in the paper text |
| cold review round 2: aggregate scope | PASS — Section 2.3.1 explicitly separates pair decomposition from uncontrolled aggregate spectral interaction |
| cold review round 2: real-symmetry parity scope | PASS — Section 5.4 states the dependence explicitly |
| cold review round 2: \(x_0=0,h'=0\) clarification | PASS — Section 6 includes an exact example and the \(-m/18\) coefficient |
| cold review round 2: Bombieri positioning | PASS — the off-line/negative-inertia correspondence is stated as known background |
| EN synchronization + JA↔EN differential audit | PREVIOUS PASS — rerun after the V1.0 patch |

## A.3 Remaining Gates before V1.0 Freeze

1. Run the final JA↔EN differential audit and code-to-paper check for the citations added by the V1.0 patch.
2. Produce and insert Figures 1–4 in LaTeX and verify captions.
3. After LaTeX typesetting, audit equations, references, and page breaks.
4. Fix the final SHA-256 of the Frozen candidate and create the package manifest.

---

**End of Version 1.0 — Publication Candidate Working Draft (English / Synchronized)**
